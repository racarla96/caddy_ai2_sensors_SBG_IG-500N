#include "sbgMatLabHelpers.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//----------------------------------------------------------------------//
//-  Masks and enums definitions                                       -//
//----------------------------------------------------------------------//

SbgConstValueItem continuousModes[] =	{	{"SBG_CONT_TRIGGER_MODE_DISABLE", SBG_CONT_TRIGGER_MODE_DISABLE},
											{"SBG_CONTINUOUS_MODE_ENABLE", SBG_CONTINUOUS_MODE_ENABLE},
											{"SBG_TRIGGERED_MODE_ENABLE", SBG_TRIGGERED_MODE_ENABLE},
											{"", 0} };

SbgConstValueItem outputModeList[] =	{	{"SBG_OUTPUT_MODE_DEFAULT", SBG_OUTPUT_MODE_DEFAULT},
											{"SBG_OUTPUT_MODE_BIG_ENDIAN", SBG_OUTPUT_MODE_BIG_ENDIAN},
											{"SBG_OUTPUT_MODE_LITTLE_ENDIAN", SBG_OUTPUT_MODE_LITTLE_ENDIAN},
											{"SBG_OUTPUT_MODE_FLOAT", SBG_OUTPUT_MODE_FLOAT},
											{"SBG_OUTPUT_MODE_FIXED", SBG_OUTPUT_MODE_FIXED},
											{"", 0} };

SbgConstValueItem protocolModeList[] =	{	{"SBG_PROTOCOL_DIS_TX_EMI_REDUCTION", SBG_PROTOCOL_DIS_TX_EMI_REDUCTION},
											{"SBG_PROTOCOL_EN_TX_EMI_REDUCTION", SBG_PROTOCOL_EN_TX_EMI_REDUCTION},
											{"", 0} };

SbgConstValueItem devicePowerModes[] =	{	{"SBG_DEVICE_NORMAL", SBG_DEVICE_NORMAL},
											{"SBG_DEVICE_MAX_PERF", SBG_DEVICE_MAX_PERF},
											{"", 0} };

SbgConstValueItem gpsPowerModeList[] =	{	{"SBG_GPS_MAX_PERF", SBG_GPS_MAX_PERF},
											{"SBG_GPS_ECO_MODE_1", SBG_GPS_ECO_MODE_1},
											{"SBG_GPS_ECO_MODE_2", SBG_GPS_ECO_MODE_2},
											{"SBG_GPS_OFF_MODE", SBG_GPS_OFF_MODE},
											{"", 0} };

SbgConstValueItem outputMaskList[] =	{	{"SBG_OUTPUT_QUATERNION", SBG_OUTPUT_QUATERNION},
											{"SBG_OUTPUT_EULER", SBG_OUTPUT_EULER},
											{"SBG_OUTPUT_MATRIX", SBG_OUTPUT_MATRIX},
											{"SBG_OUTPUT_GYROSCOPES", SBG_OUTPUT_GYROSCOPES},
											{"SBG_OUTPUT_ACCELEROMETERS", SBG_OUTPUT_ACCELEROMETERS},
											{"SBG_OUTPUT_MAGNETOMETERS", SBG_OUTPUT_MAGNETOMETERS},
											{"SBG_OUTPUT_TEMPERATURES", SBG_OUTPUT_TEMPERATURES},
											{"SBG_OUTPUT_GYROSCOPES_RAW", SBG_OUTPUT_GYROSCOPES_RAW},
											{"SBG_OUTPUT_ACCELEROMETERS_RAW", SBG_OUTPUT_ACCELEROMETERS_RAW},
											{"SBG_OUTPUT_MAGNETOMETERS_RAW", SBG_OUTPUT_MAGNETOMETERS_RAW},
											{"SBG_OUTPUT_TEMPERATURES_RAW", SBG_OUTPUT_TEMPERATURES_RAW},
											{"SBG_OUTPUT_TIME_SINCE_RESET", SBG_OUTPUT_TIME_SINCE_RESET},
											{"SBG_OUTPUT_DEVICE_STATUS", SBG_OUTPUT_DEVICE_STATUS},
											{"SBG_OUTPUT_GPS_POSITION", SBG_OUTPUT_GPS_POSITION},
											{"SBG_OUTPUT_GPS_NAVIGATION", SBG_OUTPUT_GPS_NAVIGATION},
											{"SBG_OUTPUT_GPS_ACCURACY", SBG_OUTPUT_GPS_ACCURACY},
											{"SBG_OUTPUT_GPS_INFO", SBG_OUTPUT_GPS_INFO},
											{"SBG_OUTPUT_BARO_ALTITUDE", SBG_OUTPUT_BARO_ALTITUDE},
											{"SBG_OUTPUT_BARO_PRESSURE", SBG_OUTPUT_BARO_PRESSURE},
											{"SBG_OUTPUT_POSITION", SBG_OUTPUT_POSITION},
											{"SBG_OUTPUT_VELOCITY", SBG_OUTPUT_VELOCITY},
											{"SBG_OUTPUT_ATTITUDE_ACCURACY", SBG_OUTPUT_ATTITUDE_ACCURACY},
											{"SBG_OUTPUT_NAV_ACCURACY", SBG_OUTPUT_NAV_ACCURACY},
											{"SBG_OUTPUT_GYRO_TEMPERATURES", SBG_OUTPUT_GYRO_TEMPERATURES},
											{"SBG_OUTPUT_GYRO_TEMPERATURES_RAW", SBG_OUTPUT_GYRO_TEMPERATURES_RAW},
											{"SBG_OUTPUT_UTC_TIME_REFERENCE", SBG_OUTPUT_UTC_TIME_REFERENCE},
											{"SBG_OUTPUT_MAG_CALIB_DATA", SBG_OUTPUT_MAG_CALIB_DATA},
											{"SBG_OUTPUT_GPS_TRUE_HEADING", SBG_OUTPUT_GPS_TRUE_HEADING},
											{"SBG_OUTPUT_ODO_VELOCITIES", SBG_OUTPUT_ODO_VELOCITIES},
											{"SBG_OUTPUT_DELTA_ANGLES", SBG_OUTPUT_DELTA_ANGLES},
											{"SBG_OUTPUT_HEAVE", SBG_OUTPUT_HEAVE},											
											{"", 0} };

SbgConstValueItem filterOptionsList[] =	{	{"SBG_FILTER_OPTION_ENABLE_ATTITUDE", SBG_FILTER_OPTION_ENABLE_ATTITUDE},
											{"", 0} };

SbgConstValueItem headingSourceList[] =	{	{"SBG_HEADING_SOURCE_NONE", SBG_HEADING_SOURCE_NONE},
											{"SBG_HEADING_SOURCE_MAGNETOMETERS", SBG_HEADING_SOURCE_MAGNETOMETERS},
											{"SBG_HEADING_SOURCE_GPS_COURSE", SBG_HEADING_SOURCE_GPS_COURSE},
											{"SBG_HEADING_SOURCE_USER", SBG_HEADING_SOURCE_USER},
											{"SBG_HEADING_SOURCE_REMOTE_MAG", SBG_HEADING_SOURCE_REMOTE_MAG},
											{"SBG_HEADING_SOURCE_REMOTE_TRUE_HEADING", SBG_HEADING_SOURCE_REMOTE_TRUE_HEADING},
											{"", 0} };

SbgConstValueItem orientOffsetTypes[] =	{	{"SBG_OFFSET_PRE_ROT", SBG_OFFSET_PRE_ROT},
											{"SBG_OFFSET_POST_ROT", SBG_OFFSET_POST_ROT},
											{"", 0} };

SbgConstValueItem autoOrientOffsets[] =	{	{"SBG_OFFSET_PRE_ROT_Z_RESET", SBG_OFFSET_PRE_ROT_Z_RESET},
											{"SBG_OFFSET_PRE_ROT_XY_RESET", SBG_OFFSET_PRE_ROT_XY_RESET},
											{"SBG_OFFSET_PRE_ROT_XYZ_RESET", SBG_OFFSET_PRE_ROT_XYZ_RESET},
											{"SBG_OFFSET_POST_ROT_Z_RESET", SBG_OFFSET_POST_ROT_Z_RESET},
											{"SBG_OFFSET_POST_ROT_XY_RESET", SBG_OFFSET_POST_ROT_XY_RESET},
											{"SBG_OFFSET_POST_ROT_XYZ_RESET", SBG_OFFSET_POST_ROT_XYZ_RESET},
											{"", 0} };

SbgConstValueItem gpsDynamicModels[] =	{	{"SBG_GPS_MODEL_STATIONARY", SBG_GPS_MODEL_STATIONARY},
											{"SBG_GPS_MODEL_PEDESTRIAN", SBG_GPS_MODEL_PEDESTRIAN},
											{"SBG_GPS_MODEL_AUTOMOTIVE", SBG_GPS_MODEL_AUTOMOTIVE},
											{"SBG_GPS_MODEL_SEA", SBG_GPS_MODEL_SEA},
											{"SBG_GPS_MODEL_AIRBONE_1G", SBG_GPS_MODEL_AIRBONE_1G},
											{"SBG_GPS_MODEL_AIRBONE_2G", SBG_GPS_MODEL_AIRBONE_2G},
											{"SBG_GPS_MODEL_AIRBONE_4G", SBG_GPS_MODEL_AIRBONE_4G},
											{"", 0} };

SbgConstValueItem gpsOptionsList[] =	{	{"SBG_GPS_DISABLE_SBAS", SBG_GPS_DISABLE_SBAS},
											{"SBG_GPS_ENABLE_SBAS_DIFF_CORRECTIONS", SBG_GPS_ENABLE_SBAS_DIFF_CORRECTIONS},
											{"SBG_GPS_ENABLE_SBAS_RANGING", SBG_GPS_ENABLE_SBAS_RANGING},
											{"SBG_GPS_ALTITUDE_ABOVE_MSL", SBG_GPS_ALTITUDE_ABOVE_MSL},
											{"", 0} };

SbgConstValueItem velocitySources[] =	{	{"SBG_VEL_SRC_GPS", SBG_VEL_SRC_GPS},
											{"SBG_VEL_SRC_USER", SBG_VEL_SRC_USER},
											{"SBG_VEL_SRC_ODO", SBG_VEL_SRC_ODO},
											{"", 0} };

SbgConstValueItem positionSources[] =	{	{"SBG_POS_SRC_GPS", SBG_POS_SRC_GPS},
											{"SBG_POS_SRC_GPS_AND_BARO", SBG_POS_SRC_GPS_AND_BARO},
											{"SBG_POS_SRC_USER", SBG_POS_SRC_USER},
											{"", 0} };

SbgConstValueItem advancedOptionsList[] =	{	{"SBG_SETTING_ENABLE_CONING", SBG_SETTING_ENABLE_CONING},
												{"SBG_SETTING_ALTITUDE_ABOVE_MSL", SBG_SETTING_ALTITUDE_ABOVE_MSL},
												{"SBG_SETTING_DECLINATION_AUTO", SBG_SETTING_DECLINATION_AUTO},
												{"SBG_SETTING_GRAVITY_AUTO", SBG_SETTING_GRAVITY_AUTO},
												{"SBG_SETTING_OUTPUT_UNBIASED_GYRO", SBG_SETTING_OUTPUT_UNBIASED_GYRO},
												{"SBG_SETTING_OUTPUT_UNBIASED_ACCEL", SBG_SETTING_OUTPUT_UNBIASED_ACCEL},
												{"SBG_SETTING_FORCE_MAG_HORIZONTAL", SBG_SETTING_FORCE_MAG_HORIZONTAL},
												{"SBG_SETTING_STATIC_INIT", SBG_SETTING_STATIC_INIT},
												{"SBG_SETTING_STATIC_INIT_UNTIL_MOTION_DETECTED", SBG_SETTING_STATIC_INIT_UNTIL_MOTION_DETECTED},
												{"", 0} };


SbgConstValueItem odoAxisList[] =	{	{"SBG_ODO_X", SBG_ODO_X},
										{"SBG_ODO_Y", SBG_ODO_Y},
										{"SBG_ODO_Z", SBG_ODO_Z},
										{"", 0} };

SbgConstValueItem odoDirectionList[] =	{	{"SBG_ODO_DIR_POSITIVE", SBG_ODO_DIR_POSITIVE},
											{"SBG_ODO_DIR_NEGATIVE", SBG_ODO_DIR_NEGATIVE},
											{"", 0} };

SbgConstValueItem triggerMaskList[] =	{	{"SBG_TRIGGER_MAIN_LOOP_DIVIDER", SBG_TRIGGER_MAIN_LOOP_DIVIDER},
											{"SBG_TRIGGER_MAGNETOMETERS", SBG_TRIGGER_MAGNETOMETERS},
											{"SBG_TRIGGER_BAROMETER", SBG_TRIGGER_BAROMETER},
											{"SBG_TRIGGER_GPS_VELOCITY", SBG_TRIGGER_GPS_VELOCITY},
											{"SBG_TRIGGER_GPS_POSITION", SBG_TRIGGER_GPS_POSITION},
											{"SBG_TRIGGER_GPS_COURSE", SBG_TRIGGER_GPS_COURSE},
											{"SBG_TRIGGER_TIME_PULSE", SBG_TRIGGER_TIME_PULSE},
											{"SBG_TRIGGER_EXT_EVENT", SBG_TRIGGER_EXT_EVENT},
											{"SBG_TRIGGER_ODO_VELOCITY_0", SBG_TRIGGER_ODO_VELOCITY_0},
											{"SBG_TRIGGER_ODO_VELOCITY_1", SBG_TRIGGER_ODO_VELOCITY_1},
											{"SBG_TRIGGER_EXT_TRUE_HEADING", SBG_TRIGGER_EXT_TRUE_HEADING},
											{"SBG_TRIGGER_VIRTUAL_ODOMETER", SBG_TRIGGER_VIRTUAL_ODOMETER},
											{"", 0} };


SbgConstValueItem logicInTypeList[] =	{	{"SBG_IN_DISABLED", SBG_IN_DISABLED},
											{"SBG_IN_EVENT", SBG_IN_EVENT},
											{"SBG_IN_TIME_PULSE", SBG_IN_TIME_PULSE},
											{"SBG_IN_ODOMETER", SBG_IN_ODOMETER},
											{"SBG_IN_ODOMETER_DIRECTION", SBG_IN_ODOMETER_DIRECTION},
											{"", 0} };

SbgConstValueItem logicInSensitivityList[] =	{	{"SBG_IN_FALLING_EDGE", SBG_IN_FALLING_EDGE},
													{"SBG_IN_RISING_EDGE", SBG_IN_RISING_EDGE},
													{"SBG_IN_LEVEL_CHANGE", SBG_IN_LEVEL_CHANGE},
													{"", 0} };

SbgConstValueItem logicInLocationList[] =	{	{"SBG_IN_STD_LOCATION", SBG_IN_STD_LOCATION},
												{"SBG_IN_EXT_LOCATION", SBG_IN_EXT_LOCATION},
												{"", 0} };

SbgConstValueItem logicOutTypeList[] =	{	{"SBG_OUT_DISABLED", SBG_OUT_DISABLED},
											{"SBG_OUT_MAIN_LOOP_START", SBG_OUT_MAIN_LOOP_START},
											{"SBG_OUT_MAIN_LOOP_DIVIDER", SBG_OUT_MAIN_LOOP_DIVIDER},
											{"SBG_OUT_TIME_PULSE_COPY", SBG_OUT_TIME_PULSE_COPY},
											{"SBG_OUT_VIRTUAL_ODO", SBG_OUT_VIRTUAL_ODO},
											{"", 0} };

SbgConstValueItem logicOutPolarityList[] =	{	{"SBG_OUT_FALLING_EDGE", SBG_OUT_FALLING_EDGE},
												{"SBG_OUT_RISING_EDGE", SBG_OUT_RISING_EDGE},
												{"SBG_OUT_TOGGLE", SBG_OUT_TOGGLE},
												{"", 0} };



SbgConstValueItem calibMagsActionList[] =	{	{"SBG_CALIB_MAGS_LOAD_DEFAULT", SBG_CALIB_MAGS_LOAD_DEFAULT},
												{"SBG_CALIB_MAGS_SAVE", SBG_CALIB_MAGS_SAVE},
												{"", 0} };

SbgConstValueItem calibGyrosActionList[] =	{	{"SBG_CALIB_GYROS_LOAD_DEFAULT", SBG_CALIB_GYROS_LOAD_DEFAULT},
												{"SBG_CALIB_GYROS_MEASURE_COARSE", SBG_CALIB_GYROS_MEASURE_COARSE},
												{"SBG_CALIB_GYROS_SAVE", SBG_CALIB_GYROS_SAVE},
												{"SBG_CALIB_GYROS_MEASURE_MEDIUM", SBG_CALIB_GYROS_MEASURE_MEDIUM},
												{"SBG_CALIB_GYROS_MEASURE_FINE", SBG_CALIB_GYROS_MEASURE_FINE},
												{"", 0} };

//----------------------------------------------------------------------//
//-  Library general operations                                        -//
//----------------------------------------------------------------------//

/*!
 *	Appends two string in a safe manner by checking the string
 *	destination max size.
 *	\param[out]	pDest				Output string result for pDst + pSrc.
 *	\param[in]	pSrc				Append pSrc to pDest.
 *	\param[in]	destSize			Max Destination size.
 *	\return							FALSE if pDest couldn't contains pSrc.
 */
bool strSafeCat(char *pDest, const char *pSrc, uint32 destSize)
{
	//
	// Check input args validity
	//
	if ( (pDest) && (pSrc) && (destSize>0) )
	{
		//
		// Check if we have enough space in pDest to hold the pSrc
		//
		if (strlen(pDest)+strlen(pSrc) < destSize)
		{
			strcat(pDest, pSrc);
			return TRUE;
		}
	}
	
	return FALSE;
}

/*!
 *	Find the key into the string.
 *	Each key present in the string should be separated using a | operator.
 *	\param[in]	pString					NULL terminated string to search for the key in.
 *	\param[in]	pKey					NULL terminated key to find.
 *	\return								TRUE if the key has been found in string.
 */
bool findExactString(const char *pString, const char *pKey)
{
	char *pCorrectedString;
	char *pCorrectedKey;
	uint32 inputStringLength;
	uint32 inputKeyLength;
	bool retValue = FALSE;

	//
	// Test input parameters
	//
	if ( (pString) && (pKey) )
	{
		//
		// Each key can be combined using a | operator
		// only the first and last keys don't have a | operator.
		// the idea is to append two | operators at the begining and at the end of
		// the input string to analyse and to do the same for the key
		// thanks to this, we will not detect an incorrect key
		//
		inputStringLength = strlen(pString);
		inputKeyLength = strlen(pKey);

		//
		// Allocate memory for the new string and key
		//
		pCorrectedString = (char*)malloc(inputStringLength + 3);
		pCorrectedKey = (char*)malloc(inputKeyLength + 3);

		//
		// Test if memory has been allocated
		//
		if ( (pCorrectedString) && (pCorrectedKey) )
		{
			//
			// Append a | at the begining of each string
			//
			pCorrectedString[0] = '|';
			pCorrectedKey[0] = '|';
			
			//
			// Copy the string and key
			//
			strcpy(pCorrectedString, pString);
			strcpy(pCorrectedKey, pKey);

			//
			// Append a | at the end of each string
			//
			strcat(pCorrectedString, "|");
			strcat(pCorrectedKey, "|");

			//
			// No, try to find the key into the string
			//
			if (strstr(pCorrectedString, pCorrectedKey) != NULL)
			{
				retValue = TRUE;
			}
		}

		//
		// Release memory if needed
		//
		SBG_FREE_ARRAY(pCorrectedString);
		SBG_FREE_ARRAY(pCorrectedKey);
	}
	
	return retValue;
}

/*!
 *	Build a string from an enum.
 *	\param[in]	value				Input enum value to build a string from.
 *	\param[out]	pEnumStr			String representing the input value enum.
 *	\param[in]	maxCount			Maximum output enum string size including the \0.
 *	\param[in]	pItemsList			Correspondance list between string and enum values.
 *	\return							SBG_NO_ERROR if the value has been converted into a string.
 */
SbgErrorCode buildStrFromEnum(uint32 value, char *pEnumStr, uint32 maxCount, const SbgConstValueItem *pItemsList)
{
	SbgErrorCode errorCode = SBG_NO_ERROR;
	uint32 i;
	
	//
	// Test input parameters
	//
	if ( (pEnumStr) && (maxCount > 1) && (pItemsList) )
	{
		//
		// First, initialize the output string
		//
		pEnumStr[0] = '\0';
		i = 0;

		//
		// For each item, test if we are able to find it in the input string
		//
		while (strlen(pItemsList[i].m_itemStr) > 0)
		{
			//
			// Test if we were able to find this item in the input value
			//
			if (value == pItemsList[i].m_itemValue)
			{
				//
				// Add this output mask string
				//
				strSafeCat(pEnumStr, pItemsList[i].m_itemStr, maxCount);
				break;
			}

			//
			// Goto next item
			//
			i++;
		}
	}
	else
	{
		errorCode = SBG_INVALID_PARAMETER;
	}

	return errorCode;
}

/*!
 *	Build a string from an set of masks.
 *	\param[in]	value				Input masks value to build a string from.
 *	\param[out]	pMasksStr			String representing the input value masks.
 *	\param[in]	maxCount			Maximum output enum string size including the \0.
 *	\param[in]	pItemsList			Correspondance list between string and masks values.
 *	\return							SBG_NO_ERROR if the value has been converted into a string.
 */
SbgErrorCode buildStrFromMasks(uint32 value, char *pMasksStr, uint32 maxCount, const SbgConstValueItem *pItemsList)
{
	SbgErrorCode errorCode = SBG_NO_ERROR;
	bool appendSeparator = FALSE;
	uint32 i;
	
	//
	// Test input parameters
	//
	if ( (pMasksStr) && (maxCount > 1) && (pItemsList) )
	{
		//
		// First, initialize the output string
		//
		pMasksStr[0] = '\0';
		i = 0;

		//
		// For each item, test if we are able to find it in the input string
		//
		while (strlen(pItemsList[i].m_itemStr) > 0)
		{
			//
			// Test if we were able to find this item in the input value
			//
			if (value&pItemsList[i].m_itemValue)
			{
				//
				// Test if we have to append a separator
				//
				if (appendSeparator)
				{
					//
					// Append the | separator
					//
					strSafeCat(pMasksStr, "|", maxCount);
				}

				//
				// Add this output mask string
				//
				strSafeCat(pMasksStr, pItemsList[i].m_itemStr, maxCount);
				
				//
				// It's not the first mask anymore so we have to append a separator
				//
				appendSeparator = TRUE;				
			}

			//
			// Goto next item
			//
			i++;
		}

		//
		// Finnaly, test if we have at least field some masks
		//
		if (strlen(pMasksStr) == 0)
		{
			//
			// No mask matches the input value so use the list of masks as an enum just in case
			// a mask with a 0 value exists.
			//
			buildStrFromEnum(0, pMasksStr, maxCount, pItemsList);			
		}
	}
	else
	{
		errorCode = SBG_INVALID_PARAMETER;
	}

	return errorCode;
}


/*!
 *	Build an enum value from a string.
 *	\param[in]	pEnumStr			Input NULL terminated enum string.
 *	\param[out]	pOutputValue		The corresponding enum value.
 *	\param[in]	pItemsList			Correspondance list between string and masks values.
 *	\return							SBG_NO_ERROR if the string has been converted into a valid value.
 */
SbgErrorCode buildEnumFromStr(const char *pEnumStr, uint32 *pOutputValue, const SbgConstValueItem *pItemsList)
{
	SbgErrorCode errorCode = SBG_NO_ERROR;
	uint32 i;
	
	//
	// Test input parameters
	//
	if ( (pEnumStr) && (pOutputValue) && (pItemsList) )
	{
		//
		// Try to find an exact match of the enum value
		//
		i = 0;

		//
		// For each item, test if we are able to find it in the input string
		//
		while (strlen(pItemsList[i].m_itemStr) > 0)
		{
			//
			// Test if we were able to find this item in the input value
			//
			if (findExactString(pEnumStr, pItemsList[i].m_itemStr) == TRUE)
			{
				//
				// The string has been found so return this enum value and quit
				//
				*pOutputValue = pItemsList[i].m_itemValue;
				return SBG_NO_ERROR;
			}

			//
			// Goto next item
			//
			i++;
		}

		//
		// No match found, we should have an invalid input string
		//
		errorCode = SBG_INVALID_PARAMETER;
	}
	else
	{
		errorCode = SBG_INVALID_PARAMETER;
	}

	return errorCode;
}

/*!
 *	Build a value from either an enum or a masks string.
 *	\param[in]	pMaskStr			Input NULL terminated masks string.
 *	\param[out]	pOutputValue		The corresponding masks value.
 *	\param[in]	pItemsList			Correspondance list between string and masks values.
 *	\return							SBG_NO_ERROR if the string has been converted into a valid value.
 */
SbgErrorCode buildMaskFromStr(const char *pMaskStr, uint32 *pOutputValue, const SbgConstValueItem *pItemsList)
{
	SbgErrorCode errorCode = SBG_NO_ERROR;
	uint32 i;
	
	//
	// Test input parameters
	//
	if ( (pMaskStr) && (pOutputValue) && (pItemsList) )
	{
		//
		// First, initialize the output value
		//
		*pOutputValue = 0;
		i = 0;

		//
		// For each item, test if we are able to find it in the input string
		//
		while (strlen(pItemsList[i].m_itemStr) > 0)
		{
			//
			// Test if we were able to find this item in the input value
			//
			if (findExactString(pMaskStr, pItemsList[i].m_itemStr) == TRUE)
			{
				//
				// The string has been found so add this item
				//
				*pOutputValue |= pItemsList[i].m_itemValue;			
			}

			//
			// Goto next item
			//
			i++;
		}
	}
	else
	{
		errorCode = SBG_INVALID_PARAMETER;
	}

	return errorCode;
}

