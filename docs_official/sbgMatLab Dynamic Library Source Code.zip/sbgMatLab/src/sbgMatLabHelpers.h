/*!
 *	\file		sbgMatLabHelpers.h
 *  \author		Raphael Siryani
 *	\date		19/09/11
 *
 *	Contains some helpers methods for the sbgMatlab library.
 *  Copyright 2007-2011 SBG Systems. All rights reserved.
 */

#ifndef __SBG_MATLAB_HELPERS_H__
#define __SBG_MATLAB_HELPERS_H__

#include <sbgCom.h>

/*!
 *	Struct used to build some string / enum values
 *	correspondances list.
 */
typedef struct _SbgConstValueItem
{
	const char	m_itemStr[128];			/*!< The item NULL terminated string. */
	uint32		m_itemValue;			/*!< The corresponding value. */
} SbgConstValueItem;

//----------------------------------------------------------------------//
//-  Masks and enums definitions                                       -//
//----------------------------------------------------------------------//


extern SbgConstValueItem continuousModes[];

extern SbgConstValueItem outputModeList[];

extern SbgConstValueItem protocolModeList[];

extern SbgConstValueItem devicePowerModes[];

extern SbgConstValueItem gpsPowerModeList[];

extern SbgConstValueItem outputMaskList[];

extern SbgConstValueItem filterOptionsList[];

extern SbgConstValueItem headingSourceList[];

extern SbgConstValueItem orientOffsetTypes[];

extern SbgConstValueItem autoOrientOffsets[];

extern SbgConstValueItem gpsDynamicModels[];

extern SbgConstValueItem gpsOptionsList[];

extern SbgConstValueItem velocitySources[];

extern SbgConstValueItem positionSources[];

extern SbgConstValueItem advancedOptionsList[];

extern SbgConstValueItem triggerMaskList[];

extern SbgConstValueItem odoAxisList[];
extern SbgConstValueItem odoDirectionList[];

extern SbgConstValueItem logicInTypeList[];
extern SbgConstValueItem logicInSensitivityList[];
extern SbgConstValueItem logicInLocationList[];

extern SbgConstValueItem logicOutTypeList[];
extern SbgConstValueItem logicOutPolarityList[];

extern SbgConstValueItem calibMagsActionList[];
extern SbgConstValueItem calibGyrosActionList[];

//----------------------------------------------------------------------//
//-  Library general operations                                        -//
//----------------------------------------------------------------------//

/*!
 *	Appends two string in a safe manner by checking the string
 *	destination max size.
 *	\param[out]	pDest				Output string result for pDst + pSrc.
 *	\param[in]	pSrc				Append pSrc to pDest.
 *	\param[in]	destSize			Max Destination size.
 *	\return							FALSE if pDest couldn't contains pSrc.
 */
bool strSafeCat(char *pDest, const char *pSrc, uint32 destSize);

/*!
 *	Find the key into the string.
 *	Each key present in the string should be separated using a | operator.
 *	\param[in]	pString					NULL terminated string to search for the key in.
 *	\param[in]	pKey					NULL terminated key to find.
 *	\return								TRUE if the key has been found in string.
 */
bool findExactString(const char *pString, const char *pKey);

/*!
 *	Build a string from an enum.
 *	\param[in]	value				Input enum value to build a string from.
 *	\param[out]	pEnumStr			String representing the input value enum.
 *	\param[in]	maxCount			Maximum output enum string size including the \0.
 *	\param[in]	pItemsList			Correspondance list between string and enum values.
 *	\return							SBG_NO_ERROR if the value has been converted into a string.
 */
SbgErrorCode buildStrFromEnum(uint32 value, char *pEnumStr, uint32 maxCount, const SbgConstValueItem *pItemsList);

/*!
 *	Build a string from an set of masks.
 *	\param[in]	value				Input masks value to build a string from.
 *	\param[out]	pMasksStr			String representing the input value masks.
 *	\param[in]	maxCount			Maximum output enum string size including the \0.
 *	\param[in]	pItemsList			Correspondance list between string and masks values.
 *	\return							SBG_NO_ERROR if the value has been converted into a string.
 */
SbgErrorCode buildStrFromMasks(uint32 value, char *pMasksStr, uint32 maxCount, const SbgConstValueItem *pItemsList);

/*!
 *	Build an enum value from a string.
 *	\param[in]	pEnumStr			Input NULL terminated enum string.
 *	\param[out]	pOutputValue		The corresponding enum value.
 *	\param[in]	pItemsList			Correspondance list between string and masks values.
 *	\return							SBG_NO_ERROR if the string has been converted into a valid value.
 */
SbgErrorCode buildEnumFromStr(const char *pEnumStr, uint32 *pOutputValue, const SbgConstValueItem *pItemsList);

/*!
 *	Build a value from either an enum or a masks string.
 *	\param[in]	pMaskStr			Input NULL terminated masks string.
 *	\param[out]	pOutputValue		The corresponding masks value.
 *	\param[in]	pItemsList			Correspondance list between string and masks values.
 *	\return							SBG_NO_ERROR if the string has been converted into a valid value.
 */
SbgErrorCode buildMaskFromStr(const char *pMaskStr, uint32 *pOutputValue, const SbgConstValueItem *pItemsList);


#endif
