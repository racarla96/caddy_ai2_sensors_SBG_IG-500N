#include "sbgMatLab.h"
#include "sbgMatLabVersion.h"
#include "windows.h"
#include "stdio.h"
#include "sbgMatLabHelpers.h"

#define SBG_TIME_OUT_BEFORE_RETRYING		200				/*!< Time out before retrying in ms. */
#define SBG_NUM_TRIALS						3				/*!< Number of trials. */
	
//----------------------------------------------------------------------//
//- Internal operations                                                -//
//----------------------------------------------------------------------//

/*!
 *	The trigger callback used to store the received frames.
 *	\param[in]	handler					The sbgCom protocol handler.
 *	\param[in]	triggerMask				The active trigger mask that has generated this output.
 *	\param[in]	pOutut					The received structure.
 *	\param[in]	usrArg					A user argument.
 */
void sbgMatLabTriggerCallback(SbgProtocolHandleInt *handler, uint32 triggerMask, SbgOutput *pOutput, void *usrArg)
{
	SbgMatLabHandle *pHandle = (SbgMatLabHandle*)usrArg;
	SbgMatLabDataContainer *pNewDeviceData;

	if ( (pHandle) && (pOutput) )
	{
		//
		// Check if we can add a new data structure in the list
		//
		if (pHandle->numReceivedData<255)
		{
			//
			// Create a new data structure
			//
			pNewDeviceData = (SbgMatLabDataContainer*)malloc(sizeof(SbgMatLabDataContainer));
			memset(pNewDeviceData, 0x00, sizeof(SbgMatLabDataContainer));
			pHandle->pDataList[pHandle->numReceivedData++] = pNewDeviceData;

			//
			// Copy the trigger mask string
			//
			buildStrFromMasks(triggerMask, pNewDeviceData->triggerMaskStr, 512, triggerMaskList);
			
			//
			// Copy the quaternion if we have one
			//
			if (pOutput->outputMask&SBG_OUTPUT_QUATERNION)
			{
				pNewDeviceData->outputData.q0 = pOutput->stateQuat[0];
				pNewDeviceData->outputData.q1 = pOutput->stateQuat[1];
				pNewDeviceData->outputData.q2 = pOutput->stateQuat[2];
				pNewDeviceData->outputData.q3 = pOutput->stateQuat[3];
			}
			else
			{
				pNewDeviceData->outputData.q0 = 1.0f;
				pNewDeviceData->outputData.q1 = 0.0f;
				pNewDeviceData->outputData.q2 = 0.0f;
				pNewDeviceData->outputData.q3 = 0.0f;
			}

			//
			// Copy the euler angles if we have one
			//
			if (pOutput->outputMask&SBG_OUTPUT_EULER)
			{
				pNewDeviceData->outputData.roll = pOutput->stateEuler[0];
				pNewDeviceData->outputData.pitch = pOutput->stateEuler[1];
				pNewDeviceData->outputData.yaw = pOutput->stateEuler[2];
			}

			//
			// Copy the euler angles if we have one
			//
			if (pOutput->outputMask&SBG_OUTPUT_MATRIX)
			{
				pNewDeviceData->outputData.ma0 = pOutput->stateMatrix[0];	pNewDeviceData->outputData.ma3 = pOutput->stateMatrix[3];	pNewDeviceData->outputData.ma6 = pOutput->stateMatrix[6];
				pNewDeviceData->outputData.ma1 = pOutput->stateMatrix[1];	pNewDeviceData->outputData.ma4 = pOutput->stateMatrix[4];	pNewDeviceData->outputData.ma7 = pOutput->stateMatrix[7];
				pNewDeviceData->outputData.ma2 = pOutput->stateMatrix[2];	pNewDeviceData->outputData.ma5 = pOutput->stateMatrix[5];	pNewDeviceData->outputData.ma8 = pOutput->stateMatrix[8];
			}
			else
			{
				pNewDeviceData->outputData.ma0 = 1.0f;	pNewDeviceData->outputData.ma3 = 0.0f;	pNewDeviceData->outputData.ma6 = 0.0f;
				pNewDeviceData->outputData.ma1 = 0.0f;	pNewDeviceData->outputData.ma4 = 1.0f;	pNewDeviceData->outputData.ma7 = 0.0f;
				pNewDeviceData->outputData.ma2 = 0.0f;	pNewDeviceData->outputData.ma5 = 0.0f;	pNewDeviceData->outputData.ma8 = 1.0f;
			}

			//
			// Copy the sensors if we have it
			//
			if (pOutput->outputMask&SBG_OUTPUT_GYROSCOPES)
			{
				pNewDeviceData->outputData.g0 = pOutput->gyroscopes[0];
				pNewDeviceData->outputData.g1 = pOutput->gyroscopes[1];
				pNewDeviceData->outputData.g2 = pOutput->gyroscopes[2];
			}

			if (pOutput->outputMask&SBG_OUTPUT_ACCELEROMETERS)
			{
				pNewDeviceData->outputData.a0 = pOutput->accelerometers[0];
				pNewDeviceData->outputData.a1 = pOutput->accelerometers[1];
				pNewDeviceData->outputData.a2 = pOutput->accelerometers[2];
			}

			if (pOutput->outputMask&SBG_OUTPUT_MAGNETOMETERS)
			{
				pNewDeviceData->outputData.m0 = pOutput->magnetometers[0];
				pNewDeviceData->outputData.m1 = pOutput->magnetometers[1];
				pNewDeviceData->outputData.m2 = pOutput->magnetometers[2];
			}

			if (pOutput->outputMask&SBG_OUTPUT_TEMPERATURES)
			{
				pNewDeviceData->outputData.t0 = pOutput->temperatures[0];
				pNewDeviceData->outputData.t1 = pOutput->temperatures[1];
			}

			if (pOutput->outputMask&SBG_OUTPUT_GYRO_TEMPERATURES)
			{
				pNewDeviceData->outputData.gT0 = pOutput->gyroTemperatures[0];
				pNewDeviceData->outputData.gT1 = pOutput->gyroTemperatures[1];
				pNewDeviceData->outputData.gT2 = pOutput->gyroTemperatures[2];
			}

			//
			// Sensors raw values
			//
			if (pOutput->outputMask&SBG_OUTPUT_ACCELEROMETERS_RAW)
			{
				pNewDeviceData->outputData.aR0 = pOutput->accelerometersRaw[0];
				pNewDeviceData->outputData.aR1 = pOutput->accelerometersRaw[1];
				pNewDeviceData->outputData.aR2 = pOutput->accelerometersRaw[2];
			}
			if (pOutput->outputMask&SBG_OUTPUT_GYROSCOPES_RAW)
			{
				pNewDeviceData->outputData.gR0 = pOutput->gyroscopesRaw[0];
				pNewDeviceData->outputData.gR1 = pOutput->gyroscopesRaw[1];
				pNewDeviceData->outputData.gR2 = pOutput->gyroscopesRaw[2];
			}
			if (pOutput->outputMask&SBG_OUTPUT_MAGNETOMETERS_RAW)
			{
				pNewDeviceData->outputData.mR0 = pOutput->magnetometersRaw[0];
				pNewDeviceData->outputData.mR1 = pOutput->magnetometersRaw[1];
				pNewDeviceData->outputData.mR2 = pOutput->magnetometersRaw[2];
			}
			if (pOutput->outputMask&SBG_OUTPUT_TEMPERATURES_RAW)
			{
				pNewDeviceData->outputData.tR0 = pOutput->temperaturesRaw[0];
				pNewDeviceData->outputData.tR1 = pOutput->temperaturesRaw[1];
			}
			if (pOutput->outputMask&SBG_OUTPUT_GYRO_TEMPERATURES_RAW)
			{
				pNewDeviceData->outputData.gTR0 = pOutput->gyroTemperaturesRaw[0];
				pNewDeviceData->outputData.gTR1 = pOutput->gyroTemperaturesRaw[1];
				pNewDeviceData->outputData.gTR2 = pOutput->gyroTemperaturesRaw[2];
			}

			//
			// Time related outputs
			//
			if (pOutput->outputMask&SBG_OUTPUT_TIME_SINCE_RESET)
			{
				pNewDeviceData->outputData.timeSinceReset = pOutput->timeSinceReset;
			}

			if (pOutput->outputMask&SBG_OUTPUT_DEVICE_STATUS)
			{
				pNewDeviceData->outputData.deviceStatus = pOutput->deviceStatus;
			}

			//
			// GPS data
			//
			if (pOutput->outputMask&SBG_OUTPUT_GPS_POSITION)
			{
				pNewDeviceData->outputData.gpsLatitude = ((double)pOutput->gpsLatitude)*1e-7;
				pNewDeviceData->outputData.gpsLongitude = ((double)pOutput->gpsLongitude)*1e-7;
				pNewDeviceData->outputData.gpsAltitude = pOutput->gpsAltitude;
			}

			if (pOutput->outputMask&SBG_OUTPUT_GPS_NAVIGATION)
			{
				pNewDeviceData->outputData.gpsV0 = pOutput->gpsVelocity[0];
				pNewDeviceData->outputData.gpsV1 = pOutput->gpsVelocity[1];
				pNewDeviceData->outputData.gpsV2 = pOutput->gpsVelocity[2];

				pNewDeviceData->outputData.gpsHeading = (float)pOutput->gpsHeading*1e-5f;
			}

			if (pOutput->outputMask&SBG_OUTPUT_GPS_ACCURACY)
			{
				pNewDeviceData->outputData.gpsHorAccuracy  = pOutput->gpsHorAccuracy;
				pNewDeviceData->outputData.gpsVertAccuracy = pOutput->gpsVertAccuracy;
				pNewDeviceData->outputData.gpsSpeedAccuracy = pOutput->gpsSpeedAccuracy;
				pNewDeviceData->outputData.gpsHeadingAccuracy = ((float)pOutput->gpsHeadingAccuracy)*1e-5f;
			}

			if (pOutput->outputMask&SBG_OUTPUT_GPS_INFO)
			{
				pNewDeviceData->outputData.gpsTimeMs = pOutput->gpsTimeMs;
				pNewDeviceData->outputData.gpsFlags = pOutput->gpsFlags;
				pNewDeviceData->outputData.gpsNbSats = pOutput->gpsNbSats;
			}

			//
			// Fill GPS true heading
			//
			if (pOutput->outputMask&SBG_OUTPUT_GPS_TRUE_HEADING)
			{
				pNewDeviceData->outputData.gpsTrueHeading = pOutput->gpsTrueHeading*1e-5f;
				pNewDeviceData->outputData.gpsTrueHeadingAccuracy = pOutput->gpsTrueHeadingAccuracy*1e-5f;
			}

			//
			// Barometrics data
			//
			if (pOutput->outputMask&SBG_OUTPUT_BARO_ALTITUDE)
			{
				pNewDeviceData->outputData.baroAltitude = (float)(pOutput->baroAltitude)/100.0f;
			}

			if (pOutput->outputMask&SBG_OUTPUT_BARO_PRESSURE)
			{
				pNewDeviceData->outputData.baroPressure = ((float)pOutput->baroPressure);
			}

			//
			// Navigation data
			//
			if (pOutput->outputMask & SBG_OUTPUT_POSITION)
			{
				pNewDeviceData->outputData.p0 = pOutput->position[0];
				pNewDeviceData->outputData.p1 = pOutput->position[1];
				pNewDeviceData->outputData.p2 = pOutput->position[2];
			}

			if (pOutput->outputMask & SBG_OUTPUT_VELOCITY)
			{
				pNewDeviceData->outputData.v0 = pOutput->velocity[0];
				pNewDeviceData->outputData.v1 = pOutput->velocity[1];
				pNewDeviceData->outputData.v2 = pOutput->velocity[2];
			}

			//
			// Accuracy data
			//
			if (pOutput->outputMask & SBG_OUTPUT_ATTITUDE_ACCURACY)
			{
				pNewDeviceData->outputData.attitudeAccuracy = pOutput->attitudeAccuracy;
			}

			if (pOutput->outputMask & SBG_OUTPUT_NAV_ACCURACY)
			{
				pNewDeviceData->outputData.velocityAccuracy = pOutput->velocityAccuracy;
				pNewDeviceData->outputData.positionAccuracy = pOutput->positionAccuracy;
			}

			//
			// UTC data
			//
			if (pOutput->outputMask & SBG_OUTPUT_UTC_TIME_REFERENCE)
			{
				pNewDeviceData->outputData.utcYear = pOutput->utcYear;
				pNewDeviceData->outputData.utcMonth = pOutput->utcMonth;
				pNewDeviceData->outputData.utcDay = pOutput->utcDay;
				pNewDeviceData->outputData.utcHour = pOutput->utcHour;
				pNewDeviceData->outputData.utcMin = pOutput->utcMin;
				pNewDeviceData->outputData.utcSec = pOutput->utcSec;
				pNewDeviceData->outputData.utcNano = pOutput->utcNano;
			}

			//
			// Magnetomters calibration data
			//
			if (pOutput->outputMask & SBG_OUTPUT_MAG_CALIB_DATA)
			{
				pNewDeviceData->outputData.magCalibData0 = ((uint32*)pOutput->magCalibData)[0];
				pNewDeviceData->outputData.magCalibData1 = ((uint32*)pOutput->magCalibData)[1];
				pNewDeviceData->outputData.magCalibData2 = ((uint32*)pOutput->magCalibData)[2];
			}

			//
			// Odometer raw velocities
			//
			if (pOutput->outputMask & SBG_OUTPUT_ODO_VELOCITIES)
			{
				pNewDeviceData->outputData.odoRawVel0 = pOutput->odoRawVelocity[0];
				pNewDeviceData->outputData.odoRawVel1 = pOutput->odoRawVelocity[1];
			}

			//
			// Delta angles
			//
			if (pOutput->outputMask & SBG_OUTPUT_DELTA_ANGLES)
			{
				pNewDeviceData->outputData.deltaAngleX = pOutput->deltaAngles[0];
				pNewDeviceData->outputData.deltaAngleY = pOutput->deltaAngles[1];
				pNewDeviceData->outputData.deltaAngleZ = pOutput->deltaAngles[2];
			}

			//
			// Heave
			//
			if (pOutput->outputMask & SBG_OUTPUT_HEAVE)
			{
				pNewDeviceData->outputData.heave = pOutput->heave;
			}
		}
	}
}

/*!
 *	The continuous Callback used to store the received frames.
 *	\param[in]	handler					The sbgCom protocol handler.
 *	\param[in]	pOutut					The received structure.
 *	\param[in]	usrArg					A user argument.
 */
void sbgMatLabContinuousCallback(SbgProtocolHandleInt *handler, SbgOutput *pOutput, void *usrArg)
{
	//
	// Call the trigger callback to fill the output struct
	//
	sbgMatLabTriggerCallback(handler, SBG_TRIGGER_MAIN_LOOP_DIVIDER, pOutput, usrArg);
}

/*!
 *	Wait enough time for a device reset.
 */
void sbgMatLabWaitForDeviceReset(void)
{
	//
	// Wait 3 seconds for a device reset
	//
	sbgSleep(3000);
}

//----------------------------------------------------------------------//
//- Library general operations                                         -//
//----------------------------------------------------------------------//

/*!
 *	Release all allocated data in the list.
 *	\param[in]	pHandle			Handle to the SbgMatLab context.
 *	\return						SBG_NO_ERROR if no error.
 */
SbgErrorCode sbgMatLabReleaseDataList(SbgMatLabHandle *pHandle)
{
	uint32 i;

	if (pHandle)
	{
		for (i=0; i<pHandle->numReceivedData; i++)
		{
			if (pHandle->pDataList[i])
			{
				free(pHandle->pDataList[i]);
				pHandle->pDataList[i] = NULL;
			}
		}
		pHandle->numReceivedData = 0;

		return SBG_NO_ERROR;
	}
	else
	{
		return SBG_NULL_POINTER;
	}
}

/*!
 *	Init the matlab library and sbgCom lib.
 *	\param[in]	deviceName						Location to open ("COM1").
 *	\param[in]	baudRate						Baud rate used to communicate with the device (115200).
 *	\param[in]	pHandle							Used to returns the created SbgMatLabHandle struct.
 *	\return										SBG_NO_ERROR if a connection with the device has been established.
 */
SbgErrorCode SBG_API sbgMatLabInit(const char *deviceName, uint32 baudRate, SbgMatLabHandle **pHandle)
{
	SbgErrorCode errorCode = SBG_NULL_POINTER;
	SbgMatLabHandle *pNewHandle;

	//
	// Check if we have a valid input pointer
	//
	if (pHandle)
	{
		//
		// For now, init *pHandle to NULL
		//
		*pHandle = NULL;

		//
		// Allocate the SbgMatLabHandle struct and init it
		//
		pNewHandle = (SbgMatLabHandle*)malloc(sizeof(SbgMatLabHandle));
		pNewHandle->numReceivedData = 0;
		pNewHandle->sbgComHandle = NULL;

		//
		// Initialise the sbgCom lib
		//
		errorCode = sbgComInit(deviceName, baudRate, &pNewHandle->sbgComHandle);

		//
		// Check if the init was ok
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Initialise the continous frame handler
			//
			sbgSetContinuousModeCallback(pNewHandle->sbgComHandle, sbgMatLabContinuousCallback, pNewHandle);
			sbgSetTriggeredModeCallback(pNewHandle->sbgComHandle, sbgMatLabTriggerCallback, pNewHandle);

			//
			// We have no error so define the *pHandle and quit
			//
			*pHandle = pNewHandle;

			return SBG_NO_ERROR;
		}

		//
		// We have an error release the allocated structure
		//
		SBG_FREE(pNewHandle);
	}

	return errorCode;
}

/*!
 *	Close and release memory for both sbgCom and sbgMatLab library.
 *	\param[in]	pHandle							The sbgMatLab library handle to release.
 *	\return										SBG_NO_ERROR if we have released the handle.
 */
SbgErrorCode SBG_API sbgMatLabClose(SbgMatLabHandle *pHandle)
{
	SbgErrorCode errorCode;

	if (pHandle)
	{
		//
		// First, close the sbgCom lib
		//
		errorCode = sbgComClose(pHandle->sbgComHandle);

		//
		// Release the received data
		//
		sbgMatLabReleaseDataList(pHandle);

		//
		// Release the structure
		//
		SBG_FREE(pHandle);
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Retreive the sbgMatLab and sbgCom libraries version.
 *	\param[out]	sbgMatLabVersion				A string used to hold the sbgMatLab version (1.0.0.0).
 *	\param[out]	sbgComVersion					A string used to hold the sbgCom version (1.0.0.0).
 */
void SBG_API sbgMatLabGetVersion(char sbgMatLabVersion[32], char sbgComVersion[32])
{
	if (sbgMatLabVersion)
	{
		strcpy(sbgMatLabVersion, SBG_MATLAB_VERSION);
	}

	//
	// Copy the sbgCom version
	//
	strcpy(sbgComVersion, sbgComGetVersionAsString());
}

/*!
 *	Convert an error code into a human readable string.
 *	\param[in]	errorCode						The errorCode to convert into a string.
 *	\param[out]	errorMsg						String buffer used to hold the error string.
 */
void SBG_API sbgMatLabErrorToString(SbgErrorCode errorCode, char errorMsg[256])
{
	sbgComErrorToString(errorCode, errorMsg);
}

//----------------------------------------------------------------------//
//- Data management operations                                         -//
//----------------------------------------------------------------------//

/*!
 *	Try to read data received in continous mode and returns the number of received data.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	pNumData						Pointer to uint32 used to hold the number of received data.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabHandleData(SbgMatLabHandle *pHandle, uint32 *pNumData)
{
	SbgErrorCode errorCode = SBG_NULL_POINTER;

	if ( (pHandle) && (pNumData) )
	{
		//
		// First discard all previous received data
		//
		sbgMatLabReleaseDataList(pHandle);

		//
		// Call the continous frames handler to get new received data
		//
		errorCode = sbgProtocolContinuousModeHandle(pHandle->sbgComHandle);

		if (errorCode == SBG_NO_ERROR)
		{
			//
			// We have received some data
			//
			*pNumData = pHandle->numReceivedData;
		}
	}

	return errorCode;
}

/*!
 *	After sbgMatLabHandleData has been called and some data has been read,<br>
 *	use this function to get a particual data in the list of received data.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	index							Index of the data we would like.
 *	\param[out]	pData							Pointer to a structure used to hold the received data.
 *	\param[out]	triggerMask						String containing a mask of triggers that have generated this data.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetData(SbgMatLabHandle *pHandle, uint32 index, SbgMatLabData *pData, char triggerMask[512])
{
	SbgErrorCode errorCode = SBG_NULL_POINTER;

	if ( (pHandle) && (pData) )
	{
		//
		// Check if we have a valid index
		//
		if (index < pHandle->numReceivedData)
		{
			//
			// Copy both the output data and the trigger mask
			//
			memcpy(pData, &pHandle->pDataList[index]->outputData, sizeof(SbgMatLabData));
			strcpy(triggerMask, pHandle->pDataList[index]->triggerMaskStr);

			errorCode = SBG_NO_ERROR;
		}
		else
		{
			errorCode = SBG_BUFFER_OVERFLOW;
		}
	}

	return errorCode;
}

//----------------------------------------------------------------------//
//- Settings commands operations                                       -//
//----------------------------------------------------------------------//

/*!
 *	Gets device information such as product code, hardware and firmware revisions
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[out]	productCode						Device product code string.
 *	\param[out]	pDeviceId						Device id.
 *	\param[out]	firmwareVersion					String containing the device firmware version. ('1.0.0.0')
 *	\param[out]	calibDataVersion				String containing the device calibration data version. ('1.0.0.0')
 *	\param[out]	mainBoardVersion				String containing the device main board hardware version. ('1.0.0.0')
 *	\param[out]	gpsBoardVersion					String containing the device gps/top board hardware version. ('1.0.0.0')
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetInfo(SbgMatLabHandle *pHandle, char productCode[32], uint32 *pDeviceId, char firmwareVersion[32], char calibDataVersion[32], char mainBoardVersion[32], char gpsBoardVersion[32])
{
	SbgErrorCode errorCode = SBG_NULL_POINTER;
	uint32 firmwareValue;
	uint32 calibDataValue;
	uint32 mainBoardValue;
	uint32 gpsBoardValue;
	uint32 trial;

	//
	// Check inputs args
	//
	if ( (pHandle) && (productCode) && (pDeviceId) && (firmwareVersion) && (calibDataVersion) && (mainBoardVersion) && (gpsBoardVersion) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Get the device infos
			//
			errorCode =  sbgGetInfos(pHandle->sbgComHandle, productCode, pDeviceId, &firmwareValue, &calibDataValue, &mainBoardValue, &gpsBoardValue);


			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
		
		//
		// Check if we have received the info
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Converts the versions values into string
			//
			sprintf(firmwareVersion,"%u.%u.%u.%u",	SBG_VERSION_GET_MAJOR(firmwareValue), SBG_VERSION_GET_MINOR(firmwareValue),
													SBG_VERSION_GET_REV(firmwareValue), SBG_VERSION_GET_BUILD(firmwareValue));
			sprintf(calibDataVersion,"%u.%u.%u.%u",	SBG_VERSION_GET_MAJOR(calibDataValue), SBG_VERSION_GET_MINOR(calibDataValue),
													SBG_VERSION_GET_REV(calibDataValue), SBG_VERSION_GET_BUILD(calibDataValue));
			sprintf(mainBoardVersion,"%u.%u.%u.%u",	SBG_VERSION_GET_MAJOR(mainBoardValue), SBG_VERSION_GET_MINOR(mainBoardValue),
													SBG_VERSION_GET_REV(mainBoardValue), SBG_VERSION_GET_BUILD(mainBoardValue));
			sprintf(gpsBoardVersion,"%u.%u.%u.%u",	SBG_VERSION_GET_MAJOR(gpsBoardValue), SBG_VERSION_GET_MINOR(gpsBoardValue),
													SBG_VERSION_GET_REV(gpsBoardValue), SBG_VERSION_GET_BUILD(gpsBoardValue));
		}
		else
		{
			//
			// Defaulting the outputs values
			//
			*pDeviceId = 0;
			strcpy(productCode, "undefined");
			strcpy(firmwareVersion, "0.0.0.0");
			strcpy(calibDataVersion, "0.0.0.0");
			strcpy(mainBoardVersion, "0.0.0.0");
			strcpy(gpsBoardVersion, "0.0.0.0");
		}
	}
	
	return errorCode;
}

/*!
 *	Defines a user selectable ID for the device
 *	\param[in]	pHandle							A valid sbgMatLab library handle.

 *	\param[in]	pUserId							Pointer to uint32 used to hold the device user id.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetUserId(SbgMatLabHandle *pHandle, uint32 userId)
{
	SbgErrorCode errorCode;
	uint32 trial;

	if (pHandle)
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Set the device user id
			//
			errorCode = sbgSetUserId(pHandle->sbgComHandle, userId);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Returns the device user id.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[out]	pUserId							Pointer to uint32 used to hold the device user id.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetUserId(SbgMatLabHandle *pHandle, uint32 *pUserId)
{
	SbgErrorCode errorCode;
	uint32 trial;

	if (pHandle)
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Get the device user id
			//
			errorCode = sbgGetUserId(pHandle->sbgComHandle, pUserId);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		} 
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Defines the baud rate of the device uart communication.<br>
 *	If the command is valid, the device acknoledge the baudrate change at the current speed and THEN change it's baud rate.<br>
 *	This command only change the baud rate on the device. It doesn't change the sbgCom library baud rate.<br>
 *	To change only the baud rate used by the library, you have to use the function sbgProtocolChangeBaud.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	baudRate						The new device baud rate to use.<br>
 *												Valid values are [9600, 19200,38400,57600,115200,230400,460800,921600].
 *	\param[in]	uartOptionsStr					Options applied on the COM port; restart the device if options are changed (only with supported hardware)
 *												 - SBG_PROTOCOL_DIS_TX_EMI_REDUCTION : Normal / Fast mode of operation
 *												 - SBG_PROTOCOL_EN_TX_EMI_REDUCTION: Slow operation for EMI reduction. 
 *												   Baudrate is then limited at 230400bps.
 *	\return										If SBG_NO_ERROR, the device has been configured to the new speed.
 */
SbgErrorCode SBG_API sbgMatLabSetProtocolMode(SbgMatLabHandle *pHandle, uint32 baudRate, const char uartOptionsStr[256])

{
	SbgErrorCode errorCode;
	uint32 uartOptions;
	uint32 trial;

	if ( (pHandle) && (uartOptionsStr) )
	{
		//
		// Build a mask value from a string
		//
		errorCode = buildMaskFromStr(uartOptionsStr, &uartOptions, protocolModeList);

		//
		// Test if the value has been extracted
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Try SBG_NUM_TRIALS to send the command
			//
			for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
			{
				//
				// Define the new protocol mode
				//
				errorCode = sbgSetProtocolMode(pHandle->sbgComHandle, baudRate, uartOptions);

				//
				// Check if the command has been sucessfully executed
				//
				if (errorCode == SBG_NO_ERROR)
				{
					break;
				}

				//
				// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
				//
				sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
				sbgProtocolFlush(pHandle->sbgComHandle);
			}

			if (errorCode == SBG_NO_ERROR)
			{
				//
				// Change the library baud rate
				//
				errorCode = sbgProtocolChangeBaud(pHandle->sbgComHandle, baudRate);
			}
		}

		return errorCode;
	}
	else
	{
		return SBG_NULL_POINTER;
	}
}

/*!
 *	Command used to get the current theorical baudrate used by the device and main port options.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[out]	pBaudRate						Theorical baud rate used by the device.
 *  \param[out]	uartOptionsStr					Options applied on the COM port: (only with supported hardware)
 *												 - SBG_PROTOCOL_DIS_TX_EMI_REDUCTION : Normal / Fast mode of operation
 *												 - SBG_PROTOCOL_EN_TX_EMI_REDUCTION: Slow operation for EMI reduction.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetProtocolMode(SbgMatLabHandle *pHandle, uint32 *pBaudRate, char uartOptionsStr[256])
{
	SbgErrorCode errorCode;
	uint32 uartOptions;
	uint32 trial;

	if ( (pHandle) && (pBaudRate) && (uartOptionsStr) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Get the protocol mode
			//
			errorCode = sbgGetProtocolMode(pHandle->sbgComHandle, pBaudRate, &uartOptions);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				//
				// Build a string given a value
				//
				errorCode = buildStrFromMasks(uartOptions, uartOptionsStr, 256, protocolModeList);

				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Defines the output mode of the target, big/little endian and float/fixed format.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	outputModeStr					String containing the output mode configuration using masks<br>
 *												SBG_OUTPUT_MODE_DEFAULT<br>
 *												SBG_OUTPUT_MODE_BIG_ENDIAN<br>
 *												SBG_OUTPUT_MODE_LITTLE_ENDIAN<br>
 *												SBG_OUTPUT_MODE_FLOAT<br>
 *												SBG_OUTPUT_MODE_FIXED<br>
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetOutputMode(SbgMatLabHandle *pHandle, const char outputModeStr[256])
{
	SbgErrorCode errorCode;
	uint32 outputMode;
	uint32 trial;

	if ( (pHandle) && (outputModeStr) )
	{
		//
		// Build a mask value from a string
		//
		errorCode = buildMaskFromStr(outputModeStr, &outputMode, outputModeList);

		//
		// Test if the string has been converted successfully
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Try SBG_NUM_TRIALS to send the command
			//
			for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
			{
				//
				// Set the output mode
				//
				errorCode = sbgSetOutputMode(pHandle->sbgComHandle, outputMode);

				//
				// Check if the command has been sucessfully executed
				//
				if (errorCode == SBG_NO_ERROR)
				{
					break;
				}

				//
				// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
				//
				sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
				sbgProtocolFlush(pHandle->sbgComHandle);
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Returns the output mode of the target, big/little endian and float/fixed format.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[out]	outputModeStr					String that will hold the output masks.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetOutputMode(SbgMatLabHandle *pHandle, char outputModeStr[256])
{
	SbgErrorCode errorCode;
	uint32 trial;
	uint8 outputMode;

	if ( (pHandle) && (outputModeStr) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Get the outputMode mask
			//
			errorCode = sbgGetOutputMode(pHandle->sbgComHandle, &outputMode);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				//
				// Build a string given a value
				//
				errorCode = buildStrFromMasks(outputMode, outputModeStr, 256, outputModeList);
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Sets the Low power modes for the IG-Device
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	devicePowerModeStr				String used to define the device power mode. (leave to SBG_DEVICE_NORMAL).
 *	\param[in]	gpsPowerModeStr					String used to define the the GPS receiver power mode. (leave to SBG_GPS_MAX_PERF if there is no GPS reveicer)	<br>
 * 												SBG_GPS_MAX_PERF	(0): Max. performance mode										<br>
 *												SBG_GPS_POWER_SAVE	(1): Power Save Mode(unsupported)								<br>
 *												SBG_GPS_ECO_MODE	(4): Eco mode	(unsupported)									<br>
 * 												SBG_GPS_OFF_MODE	(5): GPS Off mode
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetLowPowerModes(SbgMatLabHandle *pHandle,  const char devicePowerModeStr[256], const char gpsPowerModeStr[256])
{
	uint32 devicePowerModeValue;
	uint32 gpsPowerMode;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (devicePowerModeStr) && (gpsPowerModeStr) )
	{
		//
		// Build a mask value from a string
		//
		errorCode = buildEnumFromStr(devicePowerModeStr, &devicePowerModeValue, devicePowerModes);

		//
		// Test if the value has been extracted successfully
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Build a mask value from a string
			//
			errorCode = buildEnumFromStr(gpsPowerModeStr, &gpsPowerMode, gpsPowerModeList);

			//
			// Test if the value has been extracted successfully
			//
			if (errorCode == SBG_NO_ERROR)
			{
				//
				// Try SBG_NUM_TRIALS to send the command
				//
				for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
				{
					//
					// Set the low power mode
					//
					errorCode = sbgSetLowPowerModes(pHandle->sbgComHandle, devicePowerModeValue, gpsPowerMode);

					//
					// Check if the command has been sucessfully executed
					//
					if (errorCode == SBG_NO_ERROR)
					{
						//
						// Wait until the device has reset
						//
						sbgMatLabWaitForDeviceReset();
						break;
					}

					//
					// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
					//
					sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
					sbgProtocolFlush(pHandle->sbgComHandle);
				}
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Gets the Low power modes for the IG-Device
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[out]	devicePowerModeStr				Returns the device power mode as a string. (pass NULL if not used)
 *	\param[out]	gpsPowerModeStr					Returns the GPS receiver power mode as a string. (pass NULL if not used)	<br>
 * 												SBG_GPS_MAX_PERF	(0): Max. performance mode					<br>
 *												SBG_GPS_POWER_SAVE	(1): Power Save Mode(unsupported)			<br>
 *												SBG_GPS_ECO_MODE	(4): Eco mode	(unsupported)				<br>
 * 												SBG_GPS_OFF_MODE	(5): GPS Off mode
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetLowPowerModes(SbgMatLabHandle *pHandle, char devicePowerModeStr[256], char gpsPowerModeStr[256])
{
	SbgPowerModeDevice devicePowerModeValue;
	SbgPowerModeGps gpsPowerMode;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (devicePowerModeStr) && (gpsPowerModeStr) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Get the filter heading source
			//
			errorCode = sbgGetLowPowerModes(pHandle->sbgComHandle, &devicePowerModeValue, &gpsPowerMode);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				//
				// Build a string given a value
				//
				errorCode = buildStrFromEnum(devicePowerModeValue, devicePowerModeStr, 256, devicePowerModes);

				//
				// Test if the device power mode string has been built
				//
				if (errorCode == SBG_NO_ERROR)
				{
					//
					// Build a string given a value
					//
					errorCode = buildStrFromEnum(gpsPowerMode, gpsPowerModeStr, 256, gpsPowerModeList);
				}

				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Restore all settings to factory defaults (excepted for calibration data such as gyros bias and magnetometers calibration).<br>
 *	Change the library baud rate to the default 115200 value.<br>
 *	Update the protocol output mode.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabRestoreDefaultSettings(SbgMatLabHandle *pHandle)
{
	SbgErrorCode errorCode;
	uint32 trial;

	if (pHandle)
	{
		//
		// Try SBG_NUM_TRIALS to restore the device defaults settings
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Restore the default settings
			//
			errorCode = sbgRestoreDefaultSettings(pHandle->sbgComHandle);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				//
				// Wait until the device has reset
				//
				sbgMatLabWaitForDeviceReset();
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}

		//
		// Check if we the command has been executed
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Change the library baud rate to default value (115 200 bauds)
			//
			errorCode = sbgProtocolChangeBaud(pHandle->sbgComHandle, 115200);

			if (errorCode == SBG_NO_ERROR)
			{
				//
				// Try to retrive output mode of the product
				//
				for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
				{
					//
					// Update the output sbgcom output mode
					//
					errorCode = sbgGetOutputMode(pHandle->sbgComHandle, NULL);

					if (errorCode == SBG_NO_ERROR)
					{
						break;
					}

					//
					// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
					//
					sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
					sbgProtocolFlush(pHandle->sbgComHandle);
				}

				if (errorCode == SBG_NO_ERROR)
				{
					//
					// Try to retrive output mode of the product
					//
					for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
					{
						//
						// Update the sbgCom default output mask
						//
						errorCode = sbgGetDefaultOutputMask(pHandle->sbgComHandle, NULL);

						if (errorCode == SBG_NO_ERROR)
						{
							break;
						}

						//
						// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
						//
						sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
						sbgProtocolFlush(pHandle->sbgComHandle);
					}
				}
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Save current settings into the flash non volatile memory
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\return										SBG_NO_ERROR in case of a good operation
 */
SbgErrorCode SBG_API sbgMatLabSaveSettings(SbgMatLabHandle *pHandle)
{
	SbgErrorCode errorCode;
	uint32 trial;

	if (pHandle)
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Get the outputMode mask
			//
			errorCode = sbgSaveSettings(pHandle->sbgComHandle);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	This command set advanced settings options
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	advancedOptionsStr					Options bit mask store in a string.
 *	\return										SBG_NO_ERROR in case of a good operation
 */
SbgErrorCode SBG_API sbgMatLabSetAdvancedOptions(SbgMatLabHandle *pHandle, const char advancedOptionsStr[256])
{
	uint32 advancedOptions;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (advancedOptionsStr) )
	{
		//
		// Build a mask value from a string
		//
		errorCode = buildMaskFromStr(advancedOptionsStr, &advancedOptions, advancedOptionsList);

		//
		// Test if the value has been extracted
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Try SBG_NUM_TRIALS to send the command
			//
			for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
			{
				//
				// Set the advanced options
				//
				errorCode = sbgSetAdvancedOptions(pHandle->sbgComHandle, advancedOptions);

				//
				// Check if the command has been sucessfully executed
				//
				if (errorCode == SBG_NO_ERROR)
				{
					break;
				}

				//
				// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
				//
				sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
				sbgProtocolFlush(pHandle->sbgComHandle);
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}


/*!
 * This command is used to retrieve advanced options from the device
 * \param[in]	pHandle							A valid sbgMatLab library handle.
 * \param[in]	advancedOptionsStr				Options bit mask store in a string.
 * \return										SBG_NO_ERROR in case of a good operation
 */
SbgErrorCode SBG_API sbgMatLabGetAdvancedOptions(SbgMatLabHandle *pHandle, char advancedOptionsStr[256])
{
	SbgErrorCode errorCode;
	uint32 advancedOptions;
	uint32 trial;

	if ( (pHandle) && (advancedOptionsStr) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Get the advanced options
			//
			errorCode = sbgGetAdvancedOptions(pHandle->sbgComHandle, &advancedOptions);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				//
				// Build a string given a value
				//
				errorCode = buildStrFromMasks(advancedOptions, advancedOptionsStr, 256, advancedOptionsList);

				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

//----------------------------------------------------------------------//
//- Output configuration commands                                      -//
//----------------------------------------------------------------------//

/*!
 *	Define continous mode options, enabled/disabled and output frames speed.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	contModeStr						Set the continuous mode as a string:
 *												 - 	SBG_CONT_TRIGGER_MODE_DISABLE	Disable all types of continuous/triggered outputs; Only Question/Answers are used
 *												 -	SBG_CONTINUOUS_MODE_ENABLE		Enable basic continuous mode (one continuous frame at a regular time
 *												 -	SBG_TRIGGERED_MODE_ENABLE		Enable advanced triggered mode
 *	\param[in]	divider							Define the continous mode speed according to the internal device filter frequency.<br>
 *												For example if the device filter frequency has been set to 100Hz and we are using a divider of 4,<br>
 *												we will have data outputted at 100/4 = 25Hz.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetContinuousMode(SbgMatLabHandle *pHandle, const char contModeStr[256], uint8 divider)
{
	SbgErrorCode errorCode;
	uint32 continuousModeValue;
	uint32 trial;

	if ( (pHandle) && (contModeStr) )
	{
		//
		// Convert the input string to an enum
		//
		errorCode = buildEnumFromStr(contModeStr, &continuousModeValue, continuousModes);

		//
		// Test if the string has been successfully converted into an eunm
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Try SBG_NUM_TRIALS to send the command
			//
			for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
			{
				//
				// Set the continuous mode
				//
				errorCode = sbgSetContinuousMode(pHandle->sbgComHandle, continuousModeValue, divider);

				//
				// Check if the command has been sucessfully executed
				//
				if (errorCode == SBG_NO_ERROR)
				{
					break;
				}

				//
				// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
				//
				sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
				sbgProtocolFlush(pHandle->sbgComHandle);
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Returns the continous mode option.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[out]	contModeStr						Returns the continuous mode as a string:
 *												 - 	SBG_CONT_TRIGGER_MODE_DISABLE	Disable all types of continuous/triggered outputs; Only Question/Answers are used
 *												 -	SBG_CONTINUOUS_MODE_ENABLE		Enable basic continuous mode (one continuous frame at a regular time
 *												 -	SBG_TRIGGERED_MODE_ENABLE		Enable advanced triggered mode
 *	\param[out]	pDivider						The current devider used to define the speed of the continous mode.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetContinuousMode(SbgMatLabHandle *pHandle, char contModeStr[256], uint8 *pDivider)
{
	SbgErrorCode errorCode;
	SbgContOutputTypes continuousModeValue;
	uint32 trial;

	if ( (pHandle) && (contModeStr) && (pDivider) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Get the continuous mode
			//
			errorCode = sbgGetContinuousMode(pHandle->sbgComHandle, &continuousModeValue, pDivider);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				//
				// Convert the enum value into a string
				//
				errorCode = buildStrFromEnum(continuousModeValue, contModeStr, 256, continuousModes);

				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}
	
	return errorCode;
}

/*!
 *	Define the default output mask used to enable outputs for the continous mode.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	outputMaskStr					String containing all enabled outputs.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatSetDefaultOutputMask(SbgMatLabHandle *pHandle, const char outputMaskStr[256])
{
	SbgErrorCode errorCode;
	uint32 outputMask;
	uint32 trial;

	if ( (pHandle) && (outputMaskStr) )
	{
		//
		// Build a mask value from a string
		//
		errorCode = buildMaskFromStr(outputMaskStr, &outputMask, outputMaskList);

		//
		// Test if the value has been extracted successfully
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Try SBG_NUM_TRIALS to send the command
			//
			for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
			{
				//
				// Set the default output mask
				//
				errorCode = sbgSetDefaultOutputMask(pHandle->sbgComHandle, outputMask);

				//
				// Check if the command has been sucessfully executed
				//
				if (errorCode == SBG_NO_ERROR)
				{
					break;
				}

				//
				// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
				//
				sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
				sbgProtocolFlush(pHandle->sbgComHandle);
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Returns the current default output mask used by the command SBG_GET_DEFAULT_OUTPUT.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[out]	outputMaskStr					Returns a string containing the default output mask used by the device.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetDefaultOutputMask(SbgMatLabHandle *pHandle, char outputMaskStr[256])
{
	SbgErrorCode errorCode;
	uint32 outputMask;
	uint32 trial;

	if ( (pHandle) && (outputMaskStr) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Get the outputMode mask
			//
			errorCode = sbgGetDefaultOutputMask(pHandle->sbgComHandle, &outputMask);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				//
				// Build a string given a value
				//
				errorCode = buildStrFromMasks(outputMask, outputMaskStr, 256, outputMaskList);

				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}
	
	return errorCode;
}

/*!
 *	Define triggered output options
 *	\param[in]	handle							A valid sbgCom library handle.
 *	\param[in]	condId							The condition number may be 0 to 3
 *	\param[in]	triggerMaskStr					The trigger bit mask that will generate the triggered output
 *  \param[in]	outputMaskStr					Output mask defining the output buffer sent when a trigger is detected
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetTriggeredMode(SbgMatLabHandle *pHandle, uint8 condId, const char triggerMaskStr[256], const char outputMaskStr[256])
{
	SbgErrorCode errorCode;
	uint32 triggerMask;
	uint32 outputMask;
	uint32 trial;

	if ( (pHandle) && (triggerMaskStr) && (outputMaskStr) )
	{
		//
		// Build the trigger mask from a string
		//
		errorCode = buildMaskFromStr(triggerMaskStr, &triggerMask, triggerMaskList);

		//
		// Test that the output mask has been built
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Build the output mask from a string
			//
			errorCode = buildMaskFromStr(outputMaskStr, &outputMask, outputMaskList);

			//
			// Test if the value has been extracted successfully
			//
			if (errorCode == SBG_NO_ERROR)
			{
				//
				// Try SBG_NUM_TRIALS to send the command
				//
				for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
				{
					//
					// Set the default output mask
					//
					errorCode = sbgSetTriggeredMode(pHandle->sbgComHandle, condId, triggerMask, outputMask);

					//
					// Check if the command has been sucessfully executed
					//
					if (errorCode == SBG_NO_ERROR)
					{
						break;
					}

					//
					// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
					//
					sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
					sbgProtocolFlush(pHandle->sbgComHandle);
				}
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Return a triggered output condition parameters
 *	\param[in]	handle							A valid sbgCom library handle.
 *	\param[in]	condId							The condition number may be 0 to 3
 *	\param[out]	triggerMaskStr					The trigger bit mask that will generate the triggered output
 *  \param[out]	outputMaskStr					Output mask defining the output buffer sent when a trigger is detected
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetTriggeredMode(SbgMatLabHandle *pHandle, uint8 condId, char triggerMaskStr[256], char outputMaskStr[256])
{
	SbgErrorCode errorCode;
	uint32 triggerMask;
	uint32 outputMask;
	uint32 trial;

	if ( (pHandle) && (triggerMaskStr) && (outputMaskStr) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Get the outputMode mask
			//
			errorCode = sbgGetTriggeredMode(pHandle->sbgComHandle, condId, &triggerMask, &outputMask);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				//
				// Build the trigger mask string
				//
				errorCode = buildStrFromMasks(triggerMask, triggerMaskStr, 256, triggerMaskList);

				//
				// Test that the trigger mask string has been built
				//
				if (errorCode == SBG_NO_ERROR)
				{
					//
					// Build the output mask string
					//
					errorCode = buildStrFromMasks(outputMask, outputMaskStr, 256, outputMaskList);
				}

				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}
	
	return errorCode;
}

//----------------------------------------------------------------------//
//- Calibration commands                                               -//
//----------------------------------------------------------------------//

/*!
 *	Command used to start/stop/save a magnetometer calibration procedure.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	argumentStr						Define the action we would like to execute using a string.<br>
 *												Possible values are:<br>
 *												SBG_CALIB_MAGS_LOAD_DEFAULT<br>
 *												SBG_CALIB_MAGS_SAVE
 *	\return										SBG_NO_ERROR if the action has been executed sucessfully.
 */
SbgErrorCode SBG_API sbgMatLabCalibMagnetometers(SbgMatLabHandle *pHandle, const char argumentStr[256])
{
	SbgErrorCode errorCode;
	uint32 argument;
	uint32 trial;

	if ( (pHandle) && (argumentStr) )
	{
		//
		// Check which argument value we have
		//
		errorCode = buildEnumFromStr(argumentStr, &argument, calibMagsActionList);

		//
		// Test that the input argument is valid
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Try SBG_NUM_TRIALS to send the command
			//
			for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
			{
				//
				// Send the magnetometers calibration command
				//
				errorCode = sbgCalibMagnetometers(pHandle->sbgComHandle, argument);

				//
				// Check if the command has been sucessfully executed
				//
				if (errorCode == SBG_NO_ERROR)
				{
					break;
				}

				//
				// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
				//
				sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
				sbgProtocolFlush(pHandle->sbgComHandle);
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Define the current magnetometer calibration parameters.<br>
 *	This command is used, for example, by the sbgCenter when the magnetometer calibration is exectured on the computer.<br> 
 *	When this command is called, the new settings are only stored in volatile memory.<br>
 *	To save this calibration permanently, use sbgCalibMagnetometers with SBG_CALIB_SAVE argument.
 *	\param[in]	handle					Valid sbgCom library handle.
 *	\param[in]	offset					X,Y,Z offset of the magnetic field.
 *	\param[in]	crossAxis				3x3 matrix containing the rotation and deformation of the magnetic field.
 *	\return								SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabCalibMagnetometersSetTransformations(SbgMatLabHandle *pHandle, const float offset[3], const float crossAxis[9])
{
	SbgErrorCode errorCode;
	uint32 trial;

	if (pHandle)
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Set the magnetometers transformations
			//
			errorCode = sbgCalibMagnetometersSetTransformations(pHandle->sbgComHandle, offset, crossAxis);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Returns the current magnetometer calibration parameters.
 *	\param[in]	handle					Valid sbgCom library handle.
 *	\param[out]	offset					X,Y,Z offset of the magnetic field.
 *	\param[out]	crossAxis				3x3 matrix containing the rotation and deformation of the magnetic field.
 *	\return								SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabCalibMagnetometersGetTransformations(SbgMatLabHandle *pHandle, float offset[3], float crossAxis[9])
{
	SbgErrorCode errorCode;
	uint32 trial;

	if (pHandle)
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Get the magnetometers transformations
			//
			errorCode = sbgCalibMagnetometersGetTransformations(pHandle->sbgComHandle, offset, crossAxis);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Acquiere and save the current gyroscope bias value.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	argumentStr						Define the action we would like to execute using a string<br>
 *												Possible values are:<br>
 *												- SBG_CALIB_GYROS_LOAD_DEFAULT<br>
 *												- SBG_CALIB_GYROS_MEASURE_COARSE<br>
 *												- SBG_CALIB_GYROS_MEASURE_MEDIUM<br>
 *												- SBG_CALIB_GYROS_MEASURE_FINE<br>
 *												- SBG_CALIB_GYROS_SAVE<br>
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabCalibGyroBias(SbgMatLabHandle *pHandle, const char argumentStr[256])
{
	SbgErrorCode errorCode;
	uint32 argument;
	uint32 trial;

	if ( (pHandle) && (argumentStr) )
	{
		//
		// Check which argument value we have
		//
		errorCode = buildEnumFromStr(argumentStr, &argument, calibGyrosActionList);

		//
		// Test that the input argument is valid
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Try SBG_NUM_TRIALS to send the command
			//
			for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
			{
				//
				// Send the gyroscopes calibration 
				//
				errorCode = sbgCalibGyroBias(pHandle->sbgComHandle, argument);

				//
				// Check if the command has been sucessfully executed
				//
				if (errorCode == SBG_NO_ERROR)
				{
					break;
				}

				//
				// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
				//
				sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
				sbgProtocolFlush(pHandle->sbgComHandle);
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

//----------------------------------------------------------------------//
//  Kalman Filter commands                                              //
//----------------------------------------------------------------------//

/*!
 *	Defines some options regarding the Kalman Filter.<br>
 *	It's possible, for example, to enable/disable the attitude computation or to enable/disable gyro-bias estimation.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	filterOptionsStr				The Kalman filter options mask stored in a string.<br>
 *												Possible values are:<br>
 *													SBG_FILTER_OPTION_ENABLE_ATTITUDE
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetFilterAttitudeOptions(SbgMatLabHandle *pHandle, const char filterOptionsStr[256])
{
	uint32 filterOptions;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (filterOptionsStr) )
	{
		//
		// Build a mask value from a string
		//
		errorCode = buildMaskFromStr(filterOptionsStr, &filterOptions, filterOptionsList);

		//
		// Test if the value has been extracted
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Try SBG_NUM_TRIALS to send the command
			//
			for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
			{
				//
				// Set the filter attitude options
				//
				errorCode = sbgSetFilterAttitudeOptions(pHandle->sbgComHandle, filterOptions);

				//
				// Check if the command has been sucessfully executed
				//
				if (errorCode == SBG_NO_ERROR)
				{
					break;
				}

				//
				// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
				//
				sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
				sbgProtocolFlush(pHandle->sbgComHandle);
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Retreives some options regarding the Kalman Filter.<br>
 *	\param[in]	handle							Valid sbgCom library handle.
 *	\param[out]	filterOptionsStr				The Kalman filter options mask stored in a string<br>
 *												Possible values are:<br>
 *													SBG_FILTER_OPTION_ENABLE_ATTITUDE
 *	\param[in]	maxCount						Max size of pOutputMode including the '\0' char.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetFilterAttitudeOptions(SbgMatLabHandle *pHandle, char filterOptionsStr[256])
{
	SbgErrorCode errorCode;
	uint32 filterOptions;
	uint32 trial;

	if ( (pHandle) && (filterOptionsStr) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Get the outputMode mask
			//
			errorCode = sbgGetFilterAttitudeOptions(pHandle->sbgComHandle, &filterOptions);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				//
				// Build a string given a value
				//
				errorCode = buildStrFromMasks(filterOptions, filterOptionsStr, 256, filterOptionsList);

				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Defines the sensors filter cut-off frequencies and the update rate for the Kalman Filter.
 *	\param[in]	handle					Valid sbgCom library handle.
 *	\param[in]	gyroAccelsSampling		The accelerometers and gyroscopes sampling frequency in Hz.<br>
 *										This setting has no effect for IG devices with a 1 kHz fixed sampling frequency.
 *	\param[in]	cutoffGyro				Gyroscopes low-pass filter cut-off frequency in Hz.
 *	\param[in]	cutoffAccel				Accelerometers low-pass filter cut-off frequency in Hz.
 *	\param[in]	cutoffMagneto			Magnetometers low-pass filter cut-off frequency in Hz.
 *	\param[in]	mainLoopFrequency		The main loop filter refresh rate.
 *	\return								SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetFilterFrequencies(SbgMatLabHandle *pHandle, float gyroAccelsSampling, float cutoffGyro, float cutoffAccel, float cutoffMagneto, float mainLoopFrequency)
{
	SbgErrorCode errorCode;
	uint32 trial;

	if (pHandle)
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Set the filter frequencies
			//
			errorCode = sbgSetFilterFrequencies(pHandle->sbgComHandle, gyroAccelsSampling, cutoffGyro, cutoffAccel, cutoffMagneto, mainLoopFrequency);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Retrives the sensors filter cut-off frequencies and the update rate for the Kalman Filter.
 *	\param[in]	handle					Valid sbgCom library handle.
 *	\param[out]	pGyroAccelsSampling		The accelerometers and gyroscopes sampling frequency in Hz.
 *	\param[out]	pCutoffGyro				Gyroscopes low-pass filter cut-off frequency in Hz.
 *	\param[out]	pCutoffAccel			Accelerometers low-pass filter cut-off frequency in Hz.
 *	\param[out]	pCutoffMagneto			Magnetometers low-pass filter cut-off frequency in Hz.
 *	\param[out]	pMainLoopFrequency				The main loop filter refresh rate in Hz.
 *	\return								SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetFilterFrequencies(SbgMatLabHandle *pHandle, float *pGyroAccelsSampling, float *pCutoffGyro, float *pCutoffAccel, float *pCutoffMagneto, float *pMainLoopFrequency)
{
	SbgErrorCode errorCode;
	uint32 trial;

	if (pHandle)
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Get the filter frequencies
			//
			errorCode = sbgGetFilterFrequencies(pHandle->sbgComHandle, pGyroAccelsSampling, pCutoffGyro, pCutoffAccel, pCutoffMagneto, pMainLoopFrequency);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		} 
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Defines the kalman filter source for heading estimate.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.

 *	\param[in]	sourceStr						Source used in heading calculation stored a string.<br>
 *												Possible values are:<br>
 *													SBG_HEADING_SOURCE_NONE<br>
 *													SBG_HEADING_SOURCE_MAGNETOMETERS<br>
 *													SBG_HEADING_SOURCE_GPS<br>
 *													SBG_HEADING_SOURCE_EXTERNAL<br>
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetFilterHeadingSource(SbgMatLabHandle *pHandle, const char sourceStr[256])
{
	uint32 source;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (sourceStr) )
	{
		//
		// Build a mask value from a string
		//
		errorCode = buildEnumFromStr(sourceStr, &source, headingSourceList);

		//
		// Test if the value has been extracted
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Try SBG_NUM_TRIALS to send the command
			//
			for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
			{
				//
				// Set the filter heading source
				//
				errorCode = sbgSetFilterHeadingSource(pHandle->sbgComHandle, source);

				//
				// Check if the command has been sucessfully executed
				//
				if (errorCode == SBG_NO_ERROR)
				{
					break;
				}

				//
				// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
				//
				sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
				sbgProtocolFlush(pHandle->sbgComHandle);
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Retrives the kalman filter source for heading estimate.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[out]	sourceStr						Source used in heading calculation stored a string.<br>
 *												Possible values are:<br>
 *													SBG_HEADING_SOURCE_NONE<br>
 *													SBG_HEADING_SOURCE_MAGNETOMETERS<br>
 *													SBG_HEADING_SOURCE_GPS<br>
 *													SBG_HEADING_SOURCE_EXTERNAL<br>
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetFilterHeadingSource(SbgMatLabHandle *pHandle, char sourceStr[256])
{
	SbgHeadingSource source;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (sourceStr) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Get the filter heading source
			//
			errorCode = sbgGetFilterHeadingSource(pHandle->sbgComHandle, &source);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				//
				// Build a string given a value
				//
				errorCode = buildStrFromEnum(source, sourceStr, 256, headingSourceList);

				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Defines the magnetic declination in radians.<br>
 *	The declination is important for good results in navigation estimation with IG-500N devices.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.

 *	\param[in]	declination						The local magnetic declination in radians from -PI to +PI.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetMagneticDeclination(SbgMatLabHandle *pHandle, float declination)
{
	SbgErrorCode errorCode;
	uint32 trial;

	if (pHandle)
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Set the magnetic declination
			//
			errorCode = sbgSetMagneticDeclination(pHandle->sbgComHandle, declination);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Returns the magnetic declination in radians.<br>
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[out]	pDeclination					The local magnetic declination in radians from -PI to +PI.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetMagneticDeclination(SbgMatLabHandle *pHandle, float *pDeclination)
{
	SbgErrorCode errorCode;
	uint32 trial;

	if (pHandle)
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Get the magnetic declination
			//
			errorCode = sbgGetMagneticDeclination(pHandle->sbgComHandle, pDeclination);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Send a new heading inforamtion to the Kalman filter.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	heading							The new heading in radians.
 *	\param[in]	accuracy						The heading accuracy in radians.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSendFilterHeading(SbgMatLabHandle *pHandle, float heading, float accuracy)
{
	SbgErrorCode errorCode;
	uint32 trial;

	if (pHandle)
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send filter heading
			//
			errorCode = sbgSendFilterHeading(pHandle->sbgComHandle, heading, accuracy);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Defines the Heave configuration
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	enableHeave						Set to true if heave has to be computed
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetHeaveConf(SbgMatLabHandle *pHandle, bool enableHeave)
{
	SbgErrorCode errorCode;
	uint32 trial;

	if (pHandle)
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgSetHeaveConf(pHandle->sbgComHandle, enableHeave);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Returns the heave configuration
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	pEnableHeave					Set to true if heave has to be computed
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetHeaveConf(SbgMatLabHandle *pHandle, bool *pEnableHeave)
{
	SbgErrorCode errorCode;
	uint32 trial;

	if (pHandle)
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send filter heading
			//
			errorCode = sbgGetHeaveConf(pHandle->sbgComHandle, pEnableHeave);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

//----------------------------------------------------------------------//
//  Orientation commands                                                //
//----------------------------------------------------------------------//

/*!
 *	Defines the pre or post rotation to applied to the device.<br>
 *	This command is usefull to define an orientation 'offset'<br>
 *	You can either apply a pre rotation that applies directly on sensors values or<br>
 *	use a post rotation that only rotate attitude output such as euler angles.<br>
 *	<br>
 *	The post rotation isn't available for the IG-500N because, sensors, attitude,<br>
 *	velocity and position should be expressed in the same frame.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.

 *	\param[in]	offsetTypeStr					Define if it's a pre or post rotation using<br>
 *												SBG_OFFSET_PRE_ROT and SBG_OFFSET_POST_ROT strings.
 *	\param[in]	rotationMatrix					3x3 matrix that represents the rotation to apply.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetManualOrientationOffset(SbgMatLabHandle *pHandle, const char offsetTypeStr[256], const float rotationMatrix[9])
{
	SbgOffsetType offsetType;
	uint32 offsetTypeInt;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (offsetTypeStr) && (rotationMatrix) )
	{
		//
		// Build a enum value from a string
		//
		errorCode = buildEnumFromStr(offsetTypeStr, &offsetTypeInt, orientOffsetTypes);

		//
		// Test if the value has been extracted
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Copy the offset type
			//
			offsetType = offsetTypeInt;

			//
			// Try SBG_NUM_TRIALS to send the command
			//
			for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
			{
				//
				// Set the manual orientation offset
				//
				errorCode = sbgSetManualOrientationOffset(pHandle->sbgComHandle, offsetType, rotationMatrix);

				//
				// Check if the command has been sucessfully executed
				//
				if (errorCode == SBG_NO_ERROR)
				{
					//
					// Test if its a pre rotation reset
					//
					if (offsetType == SBG_OFFSET_PRE_ROT)
					{
						//
						// Wait until the device has reset
						//
						sbgMatLabWaitForDeviceReset();
					}

					//
					// Exit
					//
					break;
				}

				//
				// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
				//
				sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
				sbgProtocolFlush(pHandle->sbgComHandle);
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Returns the pre or post rotation applied to the device.<br>
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	offsetTypeStr					Define if we would like the pre or post rotation matrix using<br>
 *												SBG_OFFSET_PRE_ROT and SBG_OFFSET_POST_ROT strings.
 *	\param[out]	rotationMatrix					3x3 matrix that represents the applied rotation.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetOrientationOffset(SbgMatLabHandle *pHandle, const char offsetTypeStr[256], float rotationMatrix[9])
{
	uint32 offsetType;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (offsetTypeStr) && (rotationMatrix) )
	{
		//
		// Build a enum value from a string
		//
		errorCode = buildEnumFromStr(offsetTypeStr, &offsetType, orientOffsetTypes);

		//
		// Test if the value has been extracted
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Try SBG_NUM_TRIALS to send the command
			//
			for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
			{
				//
				// Get the manual orientation offset
				//
				errorCode = sbgGetOrientationOffset(pHandle->sbgComHandle, offsetType, rotationMatrix);

				//
				// Check if the command has been sucessfully executed
				//
				if (errorCode == SBG_NO_ERROR)
				{
					break;
				}

				//
				// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
				//
				sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
				sbgProtocolFlush(pHandle->sbgComHandle);
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Command used to automatically calcualte a pre or post rotation matrix.<br>
 *	Please refers to the device User Manual for more inforamtion.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.

 *	\param[in]	offsetTypeStr					Define the kind of auto rotation we would like.<br>
 *												Possible values are:<br>
 *													- SBG_OFFSET_PRE_ROT_Z_RESET<br>
 *													- SBG_OFFSET_PRE_ROT_XY_RESET<br>
 *													- SBG_OFFSET_PRE_ROT_XYZ_RESET<br>
 *													- SBG_OFFSET_POST_ROT_Z_RESET<br>
 *													- SBG_OFFSET_POST_ROT_XY_RESET<br>
 *													- SBG_OFFSET_POST_ROT_XYZ_RESET<br>
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetAutoOrientationOffset(SbgMatLabHandle *pHandle, const char offsetTypeStr[256])
{
	uint32 offsetType;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (offsetTypeStr) )
	{
		//
		// Build a enum value from a string
		//
		errorCode = buildEnumFromStr(offsetTypeStr, &offsetType, autoOrientOffsets);

		//
		// Test if the value has been extracted
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Try SBG_NUM_TRIALS to send the command
			//
			for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
			{
				//
				// Send the command
				//
				errorCode = sbgSetAutoOrientationOffset(pHandle->sbgComHandle, offsetType);

				//
				// Check if the command has been sucessfully executed
				//
				if (errorCode == SBG_NO_ERROR)
				{
					//
					// Test if its a pre rotation reset
					//
					if ( (offsetType == SBG_OFFSET_PRE_ROT_Z_RESET) || (offsetType == SBG_OFFSET_PRE_ROT_XY_RESET) || (offsetType == SBG_OFFSET_PRE_ROT_XYZ_RESET) )
					{
						//
						// Wait until the device has reset
						//
						sbgMatLabWaitForDeviceReset();
					}

					break;
				}

				//
				// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
				//
				sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
				sbgProtocolFlush(pHandle->sbgComHandle);
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

//----------------------------------------------------------------------//
//  Navigation commands                                                 //
//----------------------------------------------------------------------//

/*!
 *	Configures the reference pressure used for altitude calculation. (IG-30G and IG-500N only)
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *  \param[in]	reference						Reference pressure at ground in pascals.<br>
 *												If set to 0, the current pressure is considered as ground pressure.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetReferencePressure(SbgMatLabHandle *pHandle, uint32 reference)
{
	SbgErrorCode errorCode;
	uint32 trial;

	if (pHandle)
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgSetReferencePressure(pHandle->sbgComHandle, reference);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Get the reference pressure used for altitude calculation. (IG-30G and IG-500N only)
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[out]	pReference						pointer to the reference pressure
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetReferencePressure(SbgMatLabHandle *pHandle, uint32 *pReference)
{
	SbgErrorCode errorCode;
	uint32 trial;

	if (pHandle)
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgGetReferencePressure(pHandle->sbgComHandle, pReference);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Get the advanced information about Space Vehicles seen by GPS. (IG-30G and IG-500N only)
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[out]	pSvInfo							Pointer to an array of SbgGpsSVInfo structure that will contain SV information (std size 16 channels)
 *	\param[out]	pNbSV							Pointer to the number of satellites managed
 *	\param[in]	maxNbSv							Maximum number of nbSv that can be contained in the pSvInfo list.
 *	\return										SBG_NO_ERROR if no error
 */
SbgErrorCode SBG_API sbgMatLabGetSvInfo(SbgMatLabHandle *pHandle, SbgGpsSVInfo *pSvInfo, uint8 *pNbSV, uint8 maxNbSv)
{
	return SBG_ERROR;
}

/*!
 *	Configures the advanced GPS options. (IG-30G only)
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	modelStr						Dynamic platform model stored in a string:
 * 												- SBG_GPS_MODEL_STATIONARY<br>
 * 												- SBG_GPS_MODEL_PEDESTRIAN<br>
 * 												- SBG_GPS_MODEL_AUTOMOTIVE<br>
 * 												- SBG_GPS_MODEL_SEA<br>
 * 												- SBG_GPS_MODEL_AIRBONE_1G<br>
 * 												- SBG_GPS_MODEL_AIRBONE_2G<br>
 * 												- SBG_GPS_MODEL_AIRBONE_4G<br>
 *  \param[in]	optionsStr						GPS options using masks, stored in a string.<br>
 *												Available options masks are:
 *												- SBG_GPS_DISABLE_SBAS<br>
 *												- SBG_GPS_ENABLE_SBAS_DIFF_CORRECTIONS<br>
 *												- SBG_GPS_ENABLE_SBAS_RANGING<br>
 *	\return										SBG_NO_ERROR if no error
 */
SbgErrorCode SBG_API sbgMatLabSetGpsOptions(SbgMatLabHandle *pHandle, const char modelStr[256], const char optionsStr[256])
{
	SbgErrorCode errorCode;
	uint32 gpsModel;
	uint32 gpsOptions;
	uint32 trial;

	if ( (pHandle) && (modelStr) && (optionsStr) )
	{
		//
		// Build a mask value from a string
		//
		errorCode = buildEnumFromStr(modelStr, &gpsModel, gpsDynamicModels);

		//
		// Test if the value has been extracted
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Build a mask value from a string
			//
			errorCode = buildMaskFromStr(optionsStr, &gpsOptions, gpsOptionsList);

			//
			// Test if the value has been extracted
			//
			if (errorCode == SBG_NO_ERROR)
			{
				//
				// Try SBG_NUM_TRIALS to send the command
				//
				for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
				{
					//
					// Send the command
					//
					errorCode = sbgSetGpsOptions(pHandle->sbgComHandle, gpsModel, gpsOptions);

					//
					// Check if the command has been sucessfully executed
					//
					if (errorCode == SBG_NO_ERROR)
					{
						break;
					}

					//
					// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
					//
					sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
					sbgProtocolFlush(pHandle->sbgComHandle);
				}
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Get the advanced GPS options. (IG-30G only)
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[out]	modelStr						Dynamic platform model stored in a string:
 * 												- SBG_GPS_MODEL_STATIONARY<br>
 * 												- SBG_GPS_MODEL_PEDESTRIAN<br>
 * 												- SBG_GPS_MODEL_AUTOMOTIVE<br>
 * 												- SBG_GPS_MODEL_SEA<br>
 * 												- SBG_GPS_MODEL_AIRBONE_1G<br>
 * 												- SBG_GPS_MODEL_AIRBONE_2G<br>
 * 												- SBG_GPS_MODEL_AIRBONE_4G<br>
 *  \param[out]	optionsStr						GPS options using masks, such as SBAS corrections.<br>
 *												Available options masks are:
 *												- SBG_GPS_DISABLE_SBAS<br>
 *												- SBG_GPS_ENABLE_SBAS_DIFF_CORRECTIONS<br>
 *												- SBG_GPS_ENABLE_SBAS_RANGING<br>
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetGpsOptions(SbgMatLabHandle *pHandle, char modelStr[256], char optionsStr[256])
{
	SbgErrorCode errorCode;
	SbgGpsDynamicModel gpsModel;
	uint8 gpsOptions = 0;
	uint32 trial;

	if ( (pHandle) && (modelStr) && (optionsStr) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgGetGpsOptions(pHandle->sbgComHandle, &gpsModel, &gpsOptions);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				//
				// Build a string given a value
				//
				errorCode = buildStrFromEnum(gpsModel, modelStr, 256, gpsDynamicModels);

				//
				// Test if the value has been converted into a string
				//
				if (errorCode == SBG_NO_ERROR)
				{
					//
					// Build a string given a value
					//
					errorCode = buildStrFromMasks(gpsOptions, optionsStr, 256, gpsOptionsList);
				}
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Defines which source to use to aid the velocity in the navigation filter. (IG-500N only)
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	aidingSrcStr						The aiding source to use in the navigation filter stored in a string.<br>
 *												Valid options are:<br>
 *												- SBG_SRC_GPS<br>
 *												- SBG_SRC_GPS_AND_BARO<br>
 *												- SBG_SRC_EXTERNAL<br>
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetNavVelocitySrc(SbgMatLabHandle *pHandle, const char aidingSrc[256])
{
	uint32 source;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (aidingSrc) )
	{
		//
		// Build a mask value from a string
		//
		errorCode = buildEnumFromStr(aidingSrc, &source, velocitySources);

		//
		// Test if the value has been extracted
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Try SBG_NUM_TRIALS to send the command
			//
			for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
			{
				//
				// Send the command
				//
				errorCode = sbgSetNavVelocitySrc(pHandle->sbgComHandle, source);

				//
				// Check if the command has been sucessfully executed
				//
				if (errorCode == SBG_NO_ERROR)
				{
					break;
				}

				//
				// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
				//
				sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
				sbgProtocolFlush(pHandle->sbgComHandle);
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Returns which source is used to aid the velocity in the navigation filter. (IG-500N only)
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 * 	\param[out]	aidingSrcStr					The aiding source used in the navigation filter stored in a string.<br>
 *												Valid options are:<br>
 *												- SBG_SRC_GPS<br>
 *												- SBG_SRC_GPS_AND_BARO<br>
 *												- SBG_SRC_EXTERNAL<br>
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetNavVelocitySrc(SbgMatLabHandle *pHandle, char aidingSrcStr[256])
{
	SbgAidingVelSrc source;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (aidingSrcStr) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgGetNavVelocitySrc(pHandle->sbgComHandle, &source);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				//
				// Build a string given a value
				//
				errorCode = buildStrFromEnum(source, aidingSrcStr, 256, velocitySources);

				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Defines which source to use to aid the position in the navigation filter. (IG-500N only)
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 * 	\param[in]	aidingSrcStr					The aiding source to use in the navigation filter stored in a string.<br>
 *												Valid options are:<br>
 *												- SBG_SRC_GPS<br>
 *												- SBG_SRC_GPS_AND_BARO<br>
 *												- SBG_SRC_EXTERNAL<br>
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetNavPositionSrc(SbgMatLabHandle *pHandle, const char aidingSrc[256])
{
	uint32 source;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (aidingSrc) )
	{
		//
		// Build a mask value from a string
		//
		errorCode = buildEnumFromStr(aidingSrc, &source, positionSources);

		//
		// Test if the value has been extracted
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Try SBG_NUM_TRIALS to send the command
			//
			for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
			{
				//
				// Send the command
				//
				errorCode = sbgSetNavPositionSrc(pHandle->sbgComHandle, source);

				//
				// Check if the command has been sucessfully executed
				//
				if (errorCode == SBG_NO_ERROR)
				{
					break;
				}

				//
				// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
				//
				sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
				sbgProtocolFlush(pHandle->sbgComHandle);
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Returns which source is used to aid the position in the navigation filter. (IG-500N only)
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 * 	\param[out]	aidingSrcStr					The aiding source used in the navigation filter stored in a string.<br>
 *												Valid options are:<br>
 *												- SBG_SRC_GPS<br>
 *												- SBG_SRC_GPS_AND_BARO<br>
 *												- SBG_SRC_EXTERNAL<br>
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetNavPositionSrc(SbgMatLabHandle *pHandle, char aidingSrcStr[256])
{
	SbgAidingPosSrc source;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (aidingSrcStr) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgGetNavPositionSrc(pHandle->sbgComHandle, &source);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				//
				// Build a string given a value
				//
				errorCode = buildStrFromEnum(source, aidingSrcStr, 256, positionSources);

				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Defines the GPS lever arm. (IG-500N only).<br>
 *	Use this command to specifiy the vector between the device and the GPS antenna.<br>
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *  \param[in]	gpsLeverArm						X,Y,Z vector representing the distance between the device and the GPS antenna.<br>
 *												The distance is exressed in meters in the device coordinate system.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetGpsLeverArm(SbgMatLabHandle *pHandle, const float gpsLeverArm[3])
{
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (gpsLeverArm) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgSetGpsLeverArm(pHandle->sbgComHandle, gpsLeverArm);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Returns the GPS lever arm. (IG-500N only).<br>
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *  \param[out]	gpsLeverArm						X,Y,Z vector representing the distance between the device and the GPS antenna.<br>
 *												The distance is exressed in meters in the device coordinate system.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetGpsLeverArm(SbgMatLabHandle *pHandle, float gpsLeverArm[3])
{
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (gpsLeverArm) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgGetGpsLeverArm(pHandle->sbgComHandle, gpsLeverArm);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Defines the local gravity magnitude. (IG-500N only).
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *  \param[in]	gravityMagnitude				The local gravity magnitude in m.s^-2.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetGravityMagnitude(SbgMatLabHandle *pHandle, float gravityMagnitude)
{
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (gravityMagnitude) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgSetGravityMagnitude(pHandle->sbgComHandle, gravityMagnitude);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Returns the local gravity magnitude. (IG-500N only).<br>
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *  \param[out]	pGravityMagnitude				The local gravity magnitude in m.s^-2.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetGravityMagnitude(SbgMatLabHandle *pHandle, float *pGravityMagnitude)
{
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (pGravityMagnitude) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgGetGravityMagnitude(pHandle->sbgComHandle, pGravityMagnitude);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Send a new velocity information to the Navigation filter.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	velocity						The new X,Y,Z velocity that should be used by the navigation filter in m/s.
 *	\param[in]	accuracy						The velocity accuracy in m/s.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSendNavVelocity(SbgMatLabHandle *pHandle, const float velocity[3], float accuracy)
{
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (velocity) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgSendNavVelocity(pHandle->sbgComHandle, velocity, accuracy);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Send a new position information to the Navigation filter.
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	position						The new WGS84 position : latitude, longitude and altitude (above ellipsoid) in [deg, deg, meters].
 *	\param[in]	hAccuracy						The horizontal accuracy in meters.
 *	\param[in]	vAccuracy						The vertical accuracy in meters.
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSendNavPosition(SbgMatLabHandle *pHandle, const double position[3], float hAccuracy, float vAccuracy)
{
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (position) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgSendNavPosition(pHandle->sbgComHandle, position, hAccuracy, vAccuracy);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

//----------------------------------------------------------------------//
//- Odometer configurations                                            -//
//----------------------------------------------------------------------//

/*!
 *	Set the main configuration of the external odometer channels
 *	\param[in]	pHandle				A valid sbgMatLab library handle.
 *  \param[in]	channel				Odometer Channel to use 0 or 1
 *  \param[in]	axisStr				Odometer measurement axis (in sensor coordinate frame) May be:
 *										- SBG_ODO_X
 *										- SBG_ODO_Y
 *										- SBG_ODO_Z
 *  \param[in]	pulsesPerMeter		decimal number of pulses per meter
 *  \param[in]	gainError			Error in percent on the previous gain value
 *  \param[in]	gpsGainCorrection	If set to TRUE, the GPS will automatically enhance the odometer gain 
 *	\return							SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetOdoConfig(SbgMatLabHandle *pHandle, uint8 channel, const char axisStr[256], float pulsesPerMeter, uint8 gainError, bool gpsGainCorrection)
{
	uint32 axis;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (axisStr) )
	{
		//
		// Get the enum values from the strings
		//
		if (buildEnumFromStr(axisStr, &axis, odoAxisList) == SBG_NO_ERROR)
		{
			//
			// Try SBG_NUM_TRIALS to send the command
			//
			for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
			{
				//
				// Send the command
				//
				errorCode = sbgSetOdoConfig(pHandle->sbgComHandle, channel, axis, pulsesPerMeter, gainError, gpsGainCorrection);

				//
				// Check if the command has been sucessfully executed
				//
				if (errorCode == SBG_NO_ERROR)
				{
					break;
				}

				//
				// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
				//
				sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
				sbgProtocolFlush(pHandle->sbgComHandle);
			}
		}
		else
		{
			errorCode = SBG_INVALID_PARAMETER;
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Get the main configuration of the external odometer channels
 *	\param[in]	pHandle				A valid sbgMatLab library handle.
 *  \param[in]	channel				Odometer Channel to use 0 or 1
 *  \param[out]	axisStr				Odometer measurement axis (in sensor coordinate frame) May be:
 *										- SBG_ODO_X
 *										- SBG_ODO_Y
 *										- SBG_ODO_Z
 *  \param[out]	pPulsesPerMeter		decimal number of pulses per meter
 *  \param[out]	pGainError			Error in percent on the previous gain value
 *	\param[out]	pGpsGainCorrection	If set to TRUE, the GPS will automatically enhance the odometer gain
 *	\return							SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetOdoConfig(SbgMatLabHandle *pHandle, uint8 channel, char axisStr[256], float *pPulsesPerMeter, uint8 *pGainError, bool *pGpsGainCorrection)
{
	SbgOdoAxis axis;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (axisStr) && (pPulsesPerMeter) && (pGainError) && (pGpsGainCorrection) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgGetOdoConfig(pHandle->sbgComHandle, channel, &axis, pPulsesPerMeter, pGainError, pGpsGainCorrection);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}

		//
		// Test that the settings has been read
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Build a string given a value
			//
			if (buildStrFromEnum(axis, axisStr, 256, odoAxisList) == SBG_NO_ERROR)
			{
				errorCode = SBG_NO_ERROR;
			}
			else
			{
				//
				// Invalid parameter
				//
				errorCode = SBG_INVALID_PARAMETER;
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *  Configures the odometer direction for the corresponding channel
 *	\param[in]	pHandle				A valid sbgMatLab library handle.
 *  \param[in]	channel				Odometer Channel to use 0 or 1
 *  \param[in]	odoDirectionStr		Direction of the odometer. May be:
 *									- SBG_ODO_DIR_POSITIVE
 *									- SBG_ODO_DIR_NEGATIVE
 *									- SBG_ODO_DIR_AUTO
 *	\return							SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetOdoDirection(SbgMatLabHandle *pHandle, uint8 channel, const char odoDirectionStr[256])
{
	uint32 odoDirection;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (odoDirectionStr) )
	{
		//
		// Get the enum values from the strings
		//
		if (buildEnumFromStr(odoDirectionStr, &odoDirection, odoDirectionList) == SBG_NO_ERROR)
		{
			//
			// Try SBG_NUM_TRIALS to send the command
			//
			for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
			{
				//
				// Send the command
				//
				errorCode = sbgSetOdoDirection(pHandle->sbgComHandle, channel, odoDirection);

				//
				// Check if the command has been sucessfully executed
				//
				if (errorCode == SBG_NO_ERROR)
				{
					break;
				}

				//
				// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
				//
				sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
				sbgProtocolFlush(pHandle->sbgComHandle);
			}
		}
		else
		{
			errorCode = SBG_INVALID_PARAMETER;
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *  Get the odometer direction for the corresponding channel
 *	\param[in]	pHandle				A valid sbgMatLab library handle.
 *  \param[in]	channel				Odometer Channel to use 0 or 1
 *  \param[out]	odoDirectionStr		Direction of the odometer. May be:
 *									- SBG_ODO_DIR_POSITIVE
 *									- SBG_ODO_DIR_NEGATIVE
 *									- SBG_ODO_DIR_AUTO
 *	\return							SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetOdoDirection(SbgMatLabHandle *pHandle, uint8 channel, char odoDirectionStr[256])
{
	SbgOdoDirection odoDirection;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (odoDirectionStr) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgGetOdoDirection(pHandle->sbgComHandle, channel, &odoDirection);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}

		//
		// Test that the settings has been read
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Build a string given a value
			//
			if (buildStrFromEnum(odoDirection, odoDirectionStr, 256, odoDirectionList) == SBG_NO_ERROR)
			{
				errorCode = SBG_NO_ERROR;
			}
			else
			{
				//
				// Invalid parameter
				//
				errorCode = SBG_INVALID_PARAMETER;
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *  Configures the odometer lever arm for the corresponding channel
 *	\param[in]	pHandle				A valid sbgMatLab library handle.
 *  \param[in]	channel				Odometer Channel to use 0 or 1
 *  \param[in]	odoLeverArm			Lever arm of the odometer channel, with respect to the device. in meters.
 *	\return							SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetOdoLeverArm(SbgMatLabHandle *pHandle, uint8 channel, const float odoLeverArm[3])
{
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (odoLeverArm) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgSetOdoLeverArm(pHandle->sbgComHandle, channel, odoLeverArm);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *  Get the odometer lever arm for the corresponding channel
 *	\param[in]	pHandle				A valid sbgMatLab library handle.
 *  \param[in]	channel				Odometer Channel to use 0 or 1
 *  \param[out]	odoLeverArm			Lever arm of the odometer channel, with respect to the device. in meters.
 *	\return							SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetOdoLeverArm(SbgMatLabHandle *pHandle, uint8 channel, float odoLeverArm[3])
{
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (odoLeverArm) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgGetOdoLeverArm(pHandle->sbgComHandle, channel, odoLeverArm);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

//----------------------------------------------------------------------//
//- Synchronization input and output operations                        -//
//----------------------------------------------------------------------//

/*!
 *	Set a logic input channel setting
 *	\param[in]	pHandle				A valid sbgMatLab library handle.
 *	\param[in]	channel				Channel to configure. May Be 0 or 1
 *	\param[in]	inputTypeStr		Type of the logic input, may be <br>
 * 										- SBG_IN_DISABLED
 *										- SBG_IN_EVENT
 *										- SBG_IN_TIME_PULSE
 * 										- SBG_IN_ODOMETER
 * \param[in]	sensitivityStr		Sensitivity of the trigger. It may be:<br>
 * 										- SBG_IN_FALLING_EDGE
 * 										- SBG_IN_RISING_EDGE
 * 										- SBG_IN_LEVEL_CHANGE
 * \param[in]	locationStr			Physical location of the input pin for the syncIN channel 0 on IG-500E. <br>
 *										- SBG_IN_STD_LOCATION (default value, leave to this value if not used)
 *										- SBG_IN_EXT_LOCATION
 * \param[in]	nsDelay				Delay to be added before the actual trigger is taken into account (in nano seconds) delays up to 2seconds are allowed:<br>
 *									This delay is only used when the input is set to:
 * 										- SBG_IN_EVENT
 * 										- SBG_IN_MAIN_LOOP_START
 *										- SBG_IN_TIME_PULSE <br>
 * 									When used with the time pulse event, this delay can be negative, in order to simulate the time pulse propagation time
 *	\return							SBG_NO_ERROR if no error
 */
SbgErrorCode SBG_API sbgMatLabSetLogicInChannel(SbgMatLabHandle *pHandle, uint8 channel, const char inputTypeStr[256], const char sensitivityStr[256], const char locationStr[256], int32 nsDelay)
{
	uint32 inputType;
	uint32 sensitivity;
	uint32 location;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (inputTypeStr) && (sensitivityStr) && (locationStr) )
	{
		//
		// Get the enum values from the strings
		//
		if (	(buildEnumFromStr(inputTypeStr, &inputType, logicInTypeList) == SBG_NO_ERROR) &&
				(buildEnumFromStr(sensitivityStr, &sensitivity, logicInSensitivityList) == SBG_NO_ERROR) &&
				(buildEnumFromStr(locationStr, &location, logicInLocationList) == SBG_NO_ERROR) )
		{
			//
			// Try SBG_NUM_TRIALS to send the command
			//
			for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
			{
				//
				// Send the command
				//
				errorCode = sbgSetLogicInChannel(pHandle->sbgComHandle, channel, inputType, sensitivity, location, nsDelay);

				//
				// Check if the command has been sucessfully executed
				//
				if (errorCode == SBG_NO_ERROR)
				{
					break;
				}

				//
				// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
				//
				sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
				sbgProtocolFlush(pHandle->sbgComHandle);
			}
		}
		else
		{
			errorCode = SBG_INVALID_PARAMETER;
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Get a logic input channel setting
 *	\param[in]	pHandle				A valid sbgMatLab library handle.
 *	\param[in]	channel				Channel to configure. May Be 0 or 1
 *	\param[out]	inputTypeStr		Type of the logic input, may be <br>
 * 										- SBG_IN_DISABLED
 *										- SBG_IN_EVENT
 *										- SBG_IN_TIME_PULSE
 * 										- SBG_IN_ODOMETER	
 * \param[out]	sensitivityStr		Sensitivity of the trigger. It may be:<br>
 * 										- SBG_IN_FALLING_EDGE
 * 										- SBG_IN_RISING_EDGE
 * 										- SBG_IN_LEVEL_CHANGE
 * \param[out]	locationStr			Physical location of the input pin for the syncIN channel 0 on IG-500E. <br>
 *										- SBG_IN_STD_LOCATION
 *										- SBG_IN_EXT_LOCATION
 * \param[out]	pNsDelay			Delay added before the actual trigger is taken into account (in nano seconds) delays up to +2seconds are possible:<:<br>
 *									This delay is only valid when the input is set to:
 * 										- SBG_IN_EVENT
 * 										- SBG_IN_MAIN_LOOP_START
 *										- SBG_IN_TIME_PULSE <br>
 * 									When used with the time pulse event, this delay can be negative, in order to simulate the time pulse propagation time
 *	\return							SBG_NO_ERROR if no error
 */
SbgErrorCode SBG_API sbgMatLabGetLogicInChannel(SbgMatLabHandle *pHandle, uint8 channel, char inputTypeStr[256], char sensitivityStr[256], char locationStr[256], int32 *pNsDelay)
{
	SbgLogicInType inputType;
	SbgLogicInSensitivity sensitivity;
	SbgLogicInLocation location;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (inputTypeStr) && (sensitivityStr) && (locationStr) && (pNsDelay) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgGetLogicInChannel(pHandle->sbgComHandle, channel, &inputType, &sensitivity, &location, pNsDelay);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}

		//
		// Test that the settings has been read
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Build a string given a value
			//
			if (	(buildStrFromEnum(inputType, inputTypeStr, 256, logicInTypeList) == SBG_NO_ERROR) &&
					(buildStrFromEnum(sensitivity, sensitivityStr, 256, logicInSensitivityList) == SBG_NO_ERROR) &&
					(buildStrFromEnum(location, locationStr, 256, logicInLocationList) == SBG_NO_ERROR) )
			{
				errorCode = SBG_NO_ERROR;
			}
			else
			{
				//
				// Invalid parameter
				//
				errorCode = SBG_INVALID_PARAMETER;
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Set a logic output channel setting
 *	\param[in]	pHandle				A valid sbgMatLab library handle.
 *	\param[in]	channel				Channel to configure. Set always 0
 *	\param[in]	outputTypeStr		Type of the logic output, may be <br>
 * 										- SBG_OUT_DISABLED
 *										- SBG_OUT_MAIN_LOOP_START
 *										- SBG_OUT_MAIN_LOOP_DIVIDER
 *										- SBG_OUT_TIME_PULSE_COPY
 *										- SBG_OUT_VIRTUAL_ODO
 * \param[in]	polarityStr			Polarity of the out pulse. It may be:
 * 										- SBG_OUT_FALLING_EDGE
 * 										- SBG_OUT_RISING_EDGE
 * 										- SBG_OUT_TOGGLE
 *  \param[in]	duration			When the polarity is set to SBG_OUT_FALLING_EDGE or SBG_OUT_RISING_EDGE, this is the pulse duration in ms. <br>
 *									Leave to 0 if not used.
 *	\return							SBG_NO_ERROR if no error
 */
SbgErrorCode SBG_API sbgMatLabSetLogicOutChannel(SbgMatLabHandle *pHandle, uint8 channel, const char outputTypeStr[256], const char polarityStr[256], uint8 duration)
{
	uint32 outputType;
	uint32 polarity;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (outputTypeStr) && (polarityStr) )
	{
		//
		// Get the enum values from the strings
		//
		if (	(buildEnumFromStr(outputTypeStr, &outputType, logicOutTypeList) == SBG_NO_ERROR) &&
				(buildEnumFromStr(polarityStr, &polarity, logicOutPolarityList) == SBG_NO_ERROR) )
		{
			//
			// Try SBG_NUM_TRIALS to send the command
			//
			for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
			{
				//
				// Send the command
				//
				errorCode = sbgSetLogicOutChannel(pHandle->sbgComHandle, channel, outputType, polarity, duration);

				//
				// Check if the command has been sucessfully executed
				//
				if (errorCode == SBG_NO_ERROR)
				{
					break;
				}

				//
				// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
				//
				sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
				sbgProtocolFlush(pHandle->sbgComHandle);
			}
		}
		else
		{
			errorCode = SBG_INVALID_PARAMETER;
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Get a logic output channel setting
 *	\param[in]	pHandle				A valid sbgMatLab library handle.
 *	\param[in]	channel				Channel to configure. Leave always to 0
 *	\param[out]	pOutputType			Type of the logic output, may be <br>
 * 										- SBG_OUT_DISABLED
 *										- SBG_OUT_MAIN_LOOP_START
 *										- SBG_OUT_MAIN_LOOP_DIVIDER
 *										- SBG_OUT_TIME_PULSE_COPY
 *										- SBG_OUT_VIRTUAL_ODO
 * \param[out]	pPolarity			Polarity of the out pulse. It may be:
 * 										- SBG_OUT_FALLING_EDGE
 * 										- SBG_OUT_RISING_EDGE
 * 										- SBG_OUT_TOGGLE
 *  \param[out]	pDuration			When the polarity is set to SBG_OUT_FALLING_EDGE or SBG_OUT_RISING_EDGE, this is the pulse duration in ms. <br>
 *	\return							SBG_NO_ERROR if no error
 */
SbgErrorCode SBG_API sbgMatLabGetLogicOutChannel(SbgMatLabHandle *pHandle, uint8 channel, char outputTypeStr[256], char polarityStr[256], uint8 *pDuration)
{
	SbgLogicOutType outputType;
	SbgLogicOutPolarity polarity;
	SbgErrorCode errorCode;
	uint32 trial;

	if ( (pHandle) && (outputTypeStr) && (polarityStr) && (pDuration) )
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgGetLogicOutChannel(pHandle->sbgComHandle, channel, &outputType, &polarity, pDuration);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}

		//
		// Test that the settings has been read
		//
		if (errorCode == SBG_NO_ERROR)
		{
			//
			// Build a string given a value
			//
			if (	(buildStrFromEnum(outputType, outputTypeStr, 256, logicOutTypeList) == SBG_NO_ERROR) &&
					(buildStrFromEnum(polarity, polarityStr, 256, logicOutPolarityList) == SBG_NO_ERROR) )
			{
				errorCode = SBG_NO_ERROR;
			}
			else
			{
				//
				// Invalid parameter
				//
				errorCode = SBG_INVALID_PARAMETER;
			}
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Defines the distance between two pulses when sync out is configured as a virtual odometer
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[in]	distance						Distance in meters
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabSetVirtualOdoConf(SbgMatLabHandle *pHandle, float distance)
{
	SbgErrorCode errorCode;
	uint32 trial;

	if (pHandle)
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgSetVirtualOdoConf(pHandle->sbgComHandle, distance);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

/*!
 *	Retrieves the distance between two pulses when sync out is configured as a virtual odometer
 *	\param[in]	pHandle							A valid sbgMatLab library handle.
 *	\param[out]	pDistance						Distance in meters
 *	\return										SBG_NO_ERROR if no error.
 */
SbgErrorCode SBG_API sbgMatLabGetVirtualOdoConf(SbgMatLabHandle *pHandle, float *pDistance)
{
	SbgErrorCode errorCode;
	uint32 trial;

	if (pHandle)
	{
		//
		// Try SBG_NUM_TRIALS to send the command
		//
		for (trial = 0; trial < SBG_NUM_TRIALS; trial++)
		{
			//
			// Send the command
			//
			errorCode = sbgGetVirtualOdoConf(pHandle->sbgComHandle, pDistance);

			//
			// Check if the command has been sucessfully executed
			//
			if (errorCode == SBG_NO_ERROR)
			{
				break;
			}

			//
			// Wait SBG_TIME_OUT_BEFORE_RETRYING ms before retrying
			//
			sbgSleep(SBG_TIME_OUT_BEFORE_RETRYING);
			sbgProtocolFlush(pHandle->sbgComHandle);
		}
	}
	else
	{
		errorCode = SBG_NULL_POINTER;
	}

	return errorCode;
}

//----------------------------------------------------------------------//
//  DLL Main entry point                                                //
//----------------------------------------------------------------------//

/*!
 *	Main DLL entry point.
 *	\param[in]	hModule
 *	\param[in]	ul_reason_for_call
 *	\param[in]	lpReserved
 *	\return								True if no error.
 */
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved)
{
	return TRUE;
}

