/*!
 *	\file		sbgMatLabVersion.h
 *  \author		SBG-Systems (Raphael Siryani)
 *	\date		03/11/08
 *
 *	Version header file for the sbgMatLab library<br>
 *  Copyright 2007-2008 SBG Systems. All rights reserved.
 */
#ifndef __SBG_MATLAB_VERSION_H__
#define __SBG_MATLAB_VERSION_H__

//----------------------------------------------------------------------//
//- Version definitions                                                -//
//----------------------------------------------------------------------//

/*!
 *	Change log:<br>
 *	============<br>
 *	<br>
 *	<table border="0">
 *
 *	<tr><td valign="top">29/05/12:</td><td>
 *	Version 2.0.0.0 Support for sbgCom 2.0
 *	</td></tr>
 *
 *	<tr><td valign="top">19/09/11:</td><td>
 *	Version 1.5.0.0 Updated sbgMatLabSetProtocolMode/sbgMatLabGetProtocolMode to support new sbgCom<br>
 *					Updated sbgSetContinuousMode/sbgGetContinuousMode to support trigger mode.<br>
 *					Updated velocity source and position source constants definitions.
 *	</td></tr>
 *
 *	<tr><td valign="top">23/11/09:</td><td>
 *	Version 1.4.0.0 Updated magnetometers calibration procedure.<br>
 *					Added device status and mag calib outputs.<br>
 *					Added velocity constraints.<br>
 *					Added 3 trials for each command.<br>
 *	</td></tr>
 *
 *	<tr><td valign="top">19/10/09:</td><td>
 *	Version 1.3.1.1 Changed magnetometers calibration procedure.
 *	</td></tr>
 *
 *	<tr><td valign="top">08/10/09:</td><td>
 *	Version 1.3.1.0 Fixed a bug for sbgSetDefaultOutputMask with RAW output masks.
 *	</td></tr>
 *
 *	<tr><td valign="top">28/08/09:</td><td>
 *	Version 1.3.0.0 RC for 1.3 release.<br>
 *					Fixed gyro temperature bug.
 *	</td></tr>
 *
 *	<tr><td valign="top">17/07/09:</td><td>
 *	Version 1.1.0.0 Added UTC output using SBG_OUTPUT_UTC_TIME_REFERENCE.<br>
 *					Added gyros temperature output using SBG_OUTPUT_GYRO_TEMPERATURES and SBG_OUTPUT_GYRO_TEMPERATURES_RAW.<br>
 *					Added commands SBG_SET_LOW_POWER_MODE and SBG_GET_LOW_POWER_MODE.<br>
 *					Added GPS option mask SBG_GPS_ALTITUDE_ABOVE_MSL.<br>
 *					Linked against sbgCom library v1.2.5.0
 *	</td></tr>
 *
 *	<tr><td valign="top">01/02/09:</td><td>
 *	Version 1.0.6.0 added sbgMatLabGetVersion and sbgMatLabErrorToString functions.<br>
 *					added navigation functions.
 *	</td></tr>
 *
 *	<tr><td valign="top">16/12/08:</td><td>
 *	Version 1.0.0.0 initial release.<br>
 *	</td></tr>
 *	</table>
 */
#define SBG_MATLAB_VERSION		"2.0.0.0"
#define SBG_MATLAB_VERSION_U	SBG_VERSION(2,0,0,0)
#define SBG_MATLAB_VERSION_R	"2.0.0.0\0"
#define SBG_MATLAB_VERSION_W	2,0,0,0

#endif
